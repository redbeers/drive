package package_VO;

public class OrderInformationVO {
	int seq;
	String customer_id;
	int product_seq;
	public int getSeq() {
		return seq;
	}
	public void setSeq(int seq) {
		this.seq = seq;
	}
	public String getCustomer_id() {
		return customer_id;
	}
	public void setCustomer_id(String customer_id) {
		this.customer_id = customer_id;
	}
	public int getProduct_seq() {
		return product_seq;
	}
	public void setProduct_seq(int product_seq) {
		this.product_seq = product_seq;
	}
	@Override
	public String toString() {
		return "OrderInformation [seq=" + seq + ", customer_id=" + customer_id
				+ ", product_seq=" + product_seq + "]";
	}
	

}

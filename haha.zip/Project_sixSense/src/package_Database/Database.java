package package_Database;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import package_VO.AdminVO;
import package_VO.CustomerVO;
import package_VO.OrderInformationVO;
import package_VO.ProductVO;
import package_VO.QuestionVO;

public class Database {

	public static int snack_seq = 2;

	private final AdminVO admin = new AdminVO();
	// admin 계정

	private final List<CustomerVO> customerList = new ArrayList<>();
	// 손님 목록

	private final List<ProductVO> proList = new ArrayList<>();
	// 상품리스트

	private final List<QuestionVO> questionList = new ArrayList<>();

	// 손님 목록/겸 회원리스트

	private final List<OrderInformationVO> orderinfo = new ArrayList<>();

	// 고객 주문내역 리스트!!!

	/**
	 * <code>insertUser</code> 메서드는 새로운 사용자를 추가하기 위한 메서드입니다.
	 * 
	 * @param user
	 *            : 추가할 UserVO 객체
	 * @return 추가에 성공한다면 true, 실패한다면 false 반환
	 * @author
	 */

	public boolean insertUser(CustomerVO user) {
		return customerList.add(user);
	}

	/**
	 * <code>userIdUniqueCheck</code> 메서드는 입력한 id가 유일한 값이 맞는지 판별하는 메서드입니다.
	 * 
	 * @param userId
	 *            : 유효성을 확인하기 위한 String 객체
	 * @return 유일한 값이라면 true, 그렇지 않은 경우라면 false 반환
	 */
	public boolean userIdUniqueCheck(String userId) {
		if (admin.getId().equals(userId)) {
			return false;
		}
		return selectCustomer(userId) == null;
	}

	/**
	 * <code>adminLogin</code> 메서드는 해당 로그인 요청이 관리자 계정과 일치하는지 판별하는 메서드입니다.
	 * 
	 * @param loginInfo
	 *            : user_id, user_pw를 담은 Map
	 * @return 로그인에 성공한다면 true, 그렇지 않다면 false.
	 * @author
	 */
	public boolean adminLogin(Map<String, String> loginInfo) {
		return admin.getId().equals(loginInfo.get("user_id"))
				&& admin.getPw().equals(loginInfo.get("user_pw"));
	}

	/**
	 * <code>selectAllUser</code> 메서드는 모든 유저의 정보를 불러오기 위한 메서드입니다.
	 * 
	 * @return 모든 유저의 정보를 포함한 List
	 * @author
	 */
	public List<CustomerVO> selectAllUser() {
		List<CustomerVO> userList = new ArrayList<>();
		for (CustomerVO user : this.customerList) {
			userList.add(user);

		}
		return userList;
	}

	/**
	 * <code>selectUser</code> 메서드는 선택한 유저의 정보를 불러오기 위한 메서드입니다.
	 * 
	 * @param id
	 *            : 사용자의 고유 id
	 * @return 사용자의 정보를 담고 있는 UserVO 객체
	 * @author
	 */
	public CustomerVO selectCustomer(String id) {
		for (CustomerVO user : customerList) {
			if (user.getCustomerID().equals(id)) {
				return user;
			}
		}
		return null;
	}

	/**
	 * <code>userLogin</code> 메서드는 해당 로그인 요청이 사용자 계정과 일치하는지 판별하는 메서드입니다.
	 * 
	 * @param loginInfo
	 *            : user_id, user_pw를 담은 Map
	 * @return 로그인에 성공한다면 true, 그렇지 않다면 false.
	 * @author
	 */
	public boolean userLogin(Map<String, String> loginInfo) {
		if (selectCustomer(loginInfo.get("user_id")) == null) {
			return false;
		}
		return selectCustomer(loginInfo.get("user_id")).getPassword().equals(
				loginInfo.get("user_pw"));
		// && selectUser(loginInfo.get("user_id")).isActivate();
	}

	// ////////////////////////////////////

	// CRUD 중 R!!!
	public List<ProductVO> selectAllProduct() {

		List<ProductVO> productList = new ArrayList<>();
		for (ProductVO productList1 : this.proList) {
			if (productList1.isActivate()) {
				productList.add(productList1);
			}
		}
		return productList;
		// return proList;
	}

	/**
	 * selectProduct 메서드는 상품을 선택하는 메서드입니다.
	 * 
	 * @param user
	 * @author 성원제3
	 * @return 
	 */
	public ProductVO selectProduct(int pro_seq) {
		for (ProductVO select : proList) {
			if (select.getSeq() == pro_seq) {
				return select;
			}
		}
		return null;
	}

	/**
	 * insertProduct 메서드는 새로운 상품을 추가하기 위한 메서드입니다.
	 * 
	 * @param product
	 *            : 추가할 ProductVO 객체
	 * @return 추가에 성공하면 true, 실패하면 false 반환
	 * @author 성원제1
	 */
	public boolean insertProduct(ProductVO productVO) {
		return proList.add(productVO);
	}

	/**
	 * <code>removeProduct</code> 메서드는 상품을 삭제하가 위한 메서드입니다.
	 * 
	 * @param seq
	 *            :
	 * @return 추가에 성공한다면 true, 실패한다면 false 반환
	 * @author 성원제2
	 */
	public int removeProduct(int seq) {
		// 타입을 맞춰서 변수에 시퀀스를 넣어
		// 그 시퀀스를 엑티베이트에서 트루풜스로 바꿔 트루면 삭제, 폴스면 아니고
		ProductVO product = selectProduct(seq);
		if (product == null) {
			product.setActivate(true);
			return 0;
		}

		product.setActivate(false);
		return 1;
	}

	/**
	 * <code>selectAllQuestion</code> 메서드는 고객의 리스트 전부를 읽기 위한 메서드입니다.
	 * 
	 * 
	 * 
	 * @return 추가에 성공한다면 true, 실패한다면 false 반환
	 * @author 성원제4
	 */
	public List<QuestionVO> selectAllQuestion() {

		List<QuestionVO> questionList = new ArrayList<>();
		for (QuestionVO question : questionList) {
			if (question.isActivate()) {
				questionList.add(question);
			}
		}
		return questionList;
	}


	/**
	 * <code>insertOrderInformation</code> 메서드는 새로운 주문을 추가하기 위한 메서드입니다.
	 * 
	 * @param orderInformation
	 *            : 추가할 OrderInformationVO 객체
	 * @return 추가에 성공하면 true, 실패하면 false 반환
	 * @author 길민선
	 */
	public boolean insertOrderInformation(OrderInformationVO orderInformation) {
		return orderinfo.add(orderInformation);
	}
	
	/**
	 * <code>selectAllOrderInformation</code> 메서드는 모든 주문내역의 정보를 불러오기 위한 메서드입니다.
	 * 
	 * @return 모든 주문 정보를 담고 있는 List
	 * @author 길민선
	 */
	public List<OrderInformationVO> selectAllOrderInformation() {
		//손님 아이디와 일치하는 것들을 다 불러와 담아-> 반환
		return orderinfo;
	}
	
	
	
	

	// /////////////////////
	// ////////////////////////////////////////////
	{
		ProductVO prod1 = new ProductVO();
		prod1.setSeq(1);
		prod1.setName("새우깡");
		prod1.setPrice(1000);
		prod1.setStock(100);
		proList.add(prod1);

		ProductVO prod2 = new ProductVO();
		prod2.setSeq(2);
		prod2.setName("포카칩");
		prod2.setPrice(1000);
		prod2.setStock(500);
		proList.add(prod2);
	}
	// ///////////////////////////////////
	// CustomerVO 초기화 블럭
	{
		CustomerVO user1 = new CustomerVO();
		user1.setCustomerID("1");
		user1.setPassword("1");
		user1.setName("길민선");
		user1.setPoint(10000);
		customerList.add(user1);

	}
	// ///////////////////////////////////
	// QuestionVO 초기화 블럭
	{
		QuestionVO question1 = new QuestionVO();
		question1.setSeq_num(1);
		question1.setTitle("저기요...이건 아니잖아요");
		question1
				.setContent("아니..제품이 왜케 없어요 두개라뇨..매장은 20평인데 말이 되나요??\r 두개 사러 여기까지 오게했다고?");
		question1.setAswer("죄송해요..ㅠㅡㅠ");
		question1.getCustomer_id();
	}
}

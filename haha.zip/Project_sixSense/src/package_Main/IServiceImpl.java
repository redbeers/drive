package package_Main;

import java.util.List;
import java.util.Map;

import package_Database.Database;
import package_VO.CustomerVO;
import package_VO.OrderInformationVO;
import package_VO.ProductVO;
import package_VO.QuestionVO;

public class IServiceImpl implements IService {
	Database db = new Database();

	/**
	 * <상품 리스트 보기>
	 * 
	 * @return
	 * @param 리스트
	 *            다 불러오는 거니까 파라미터 없음
	 * @author
	 * 
	 */
	@Override
	public List<ProductVO> selectAllProduct() {
		return db.selectAllProduct();
	}

	/**
	 * <상품 추가> 관리자 메서드
	 * 
	 * @since 21.01.28
	 * @author 성원제1
	 */
	@Override
	public boolean insertProduct(ProductVO productVO) {
		return db.insertProduct(productVO);
	}

	/**
	 * <상품 삭제> 관리자 메서드
	 * 
	 * @since 21.01.29.
	 * @author 성원제2
	 */
	@Override
	public int removeProduct(int pro_seq) {
		db.removeProduct(pro_seq);
		return 1;
	}

	/**
	 * <고객의 소리 리스트 보기> 관리자 메서드 데이터 베이스에 메서드 추가해야돼
	 * 
	 * @since 21.01.29.
	 * @author 성원제3
	 * 
	 *******************************여기 고쳐야돼*****************************
	 */
	@Override
	public List<QuestionVO> selectAllQuestion() {
		return null;
	}

	/**
	 * 회원가입 - 유저 정보 DB에 입력
	 * 
	 * @param user
	 * @return 성공 시 true, 실패 시 false 반환
	 * @author
	 */
	@Override
	public boolean insertUser(CustomerVO user) {
		return db.insertUser(user);
	}

	@Override
	public boolean checkId(String id) {
		return db.userIdUniqueCheck(id);
	}

	@Override
	public boolean adminLogin(Map<String, String> loginInfo) {
		return db.adminLogin(loginInfo);
	}

	@Override
	public boolean userLogin(Map<String, String> loginInfo) {
		return db.userLogin(loginInfo);
	}

	@Override
	public CustomerVO selectCustomer(String user_id) {
		return db.selectCustomer(user_id);
	}

	/**
	 * 주문 정보 추가 - 고객 메서드
	 * 고객이 구매한 정보를 추가해야함
	 * @param orderInformation
	 * @return 성공 시 true, 실패 시 false 반환
	 * @author 길민선
	 */
	@Override
	public boolean insertOrderInformation(OrderInformationVO orderInformation) {
		return db.insertOrderInformation(orderInformation);
	}
	
	
	/**
	 * 주문 정보 보기 - 고객 메서드
	 * 고객이 구매한 정보를 보기
	 * @param orderInformation
	 * @return 성공 시 true, 실패 시 false 반환
	 * @author 길민선
	 */
//	@Override
//	public List<OrderInformationVO> selectAllOrderInformation(String customer_id) {
//		return database.selectOrderInformation(user_id);
//	}
//}
	@Override
	public List<OrderInformationVO> selectAllOrderInformation() {
		return db.selectAllOrderInformation();
	}
	
	
	
	
	
}

package package_VO;

public class RefundVO {
	private int refundID;
	private int mount;
	private int orderedList_ID;

	public int getRefundID() {
		return refundID;
	}

	public void setRefundID(int refundID) {
		this.refundID = refundID;
	}

	public int getMount() {
		return mount;
	}

	public void setMount(int mount) {
		this.mount = mount;
	}

	public int getOrderedList_ID() {
		return orderedList_ID;
	}

	public void setOrderedList_ID(int orderedList_ID) {
		this.orderedList_ID = orderedList_ID;
	}

}

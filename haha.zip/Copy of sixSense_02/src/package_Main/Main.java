package package_Main;

public class Main {
	public static void main(String[] args) {
	View_00 view = new View_00();
	view.mainScreen();
	System.out.println("🪐잘가🌍");
	}
}

jumsu = 10

if jumsu >= 90:
    print("수")
elif jumsu >= 80:
    print("우")
elif jumsu >= 70:
    print("미")
elif jumsu >= 60:
    print("야")
else:
    print("가")

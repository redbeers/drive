sum = 0

for i in range(11):
    sum +=i
print(sum)

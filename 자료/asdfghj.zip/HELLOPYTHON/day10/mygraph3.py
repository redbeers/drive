import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import axes3d, Axes3D  
import cx_Oracle
from astropy.units import zs
import numpy as np

def getCprice(s_name):
    conn = cx_Oracle.connect('python/python@localhost:1521/xe')
    cur = conn.cursor()
    cur.execute("SELECT cprice FROM stock WHERE s_name='"+s_name+"'order by in_time")
    
    ret = []
    for record in cur:
        ret.append(record[0])
        
    cur.close()
    conn.close()
    return ret
 
fig = plt.figure()
ax = fig.gca(projection='3d')  
ax.set_zlabel('z')
ax.set_xlabel('x')
ax.set_ylabel('y')
  
s_names = ["삼성전자","LG","SK"] 

cnt = len(getCprice("삼성전자"))
y = range(cnt)
x = np.zeros(cnt)

for i,s_name in enumerate(s_names):
    z = getCprice(s_name)
    ax.plot(x+i, y, z)
    
     
#     z = getCprice(s_names[i])
#     ax.plot(x+1, y, z)
#      
#      
#     z = getCprice(s_names[i])
#     ax.plot(x+2, y, z)



plt.show()


import requests
import json
url = "https://dapi.kakao.com/v2/search/image"
queryString = {"query":"남주혁"}
header = {'authorization':'KakaoAK 1ac8389c1515c384edc9c1c7fab700d4'}
r = requests.get(url, headers=header, params=queryString)
json = json.loads(r.text)

documents = json['documents']
# for i in documents:
#     print(i['collection'],i['datetime'],i['display_sitename'],i['doc_url'],i['height'],i['image_url'],i['thumbnail_url'],i['width'])
#     for j in i.values():
#         print(j, end=" ")
#     print()

for document in documents:
    print(list(document.values()))
#     print(document["collection"], end=" ")
#     print(document["datetime"], end=" ")
#     print(document["display_sitename"], end=" ")
#     print(document["doc_url"], end=" ")
#     print(document["height"], end=" ")
#     print(document["image_url"], end=" ")
#     print(document["thumbnail_url"], end=" ")
#     print(document["width"])

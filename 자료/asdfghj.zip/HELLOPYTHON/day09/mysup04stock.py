import requests 
from bs4 import BeautifulSoup
import cx_Oracle
import os
import datetime
URL = 'https://vip.mk.co.kr/newSt/rate/item_all.php' 
response = requests.get(URL) 
# html = response.text

# 웹에서 추출하는곳
soup = BeautifulSoup(response.content.decode('euc-kr', 'replace'), 'html.parser')
tds = soup.select('.st2')

# 현재시간 만드는곳
now = datetime.datetime.now()
time = now.strftime("%Y%m%d.%H%M")

# db에 넣는곳
os.putenv('NLS_LANG', '.UTF8')
conn = cx_Oracle.connect('python','python','localhost/xe')
cs = conn.cursor()
sql = "insert into STOCK(S_CODE,S_NAME,CPRICE,IN_TIME) values(:1, :2, :3, :4)"

for i in tds:
    s_name = i.text
    s_code = i.find("a")['title']
    cprice = i.parent.find_all("td")[1].text.replace(",","")
    cs.execute(sql,(s_code,s_name,cprice,time))

 

print(cs.rowcount)
cs.close()
conn.commit()
conn.close()

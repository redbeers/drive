import cx_Oracle
  
conn = cx_Oracle.connect('python','python','localhost/xe')
cs = conn.cursor()



sql = "insert into omok(pan,pseq,history,win) values(:1, :2, :3, :4)"
cs.execute(sql,('2','2','2','2'))
print(cs.rowcount)



cs.close()
conn.commit()
conn.close()
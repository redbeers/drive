from flask import Flask
from flask import request

app = Flask(__name__)


@app.route('/hello')
def home():
    dan = request.args.get("dan")
    aaa = ""
    for i in range(1,10):
#         aaa += dan + " * " + str(i) + " = " + str(int(dan)*i)+"<br>"
#         aaa += "%s * %d = %d<br>" % (dan, i, int(dan) * i)
        aaa += f"{dan} * {i} = {int(dan) * i}<br>"
    return aaa 

    
if __name__ == '__main__':
    app.run(debug=True)

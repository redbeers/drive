# import cx_Oracle
# 
# conn = cx_Oracle.connect('python/python@localhost:1521/xe')
# cs = conn.cursor()
# cs.execute("select col01,col02,col03 from sample ")
# 
# 
# for i in cs:
#     print(i[0])
# 
# cs.close()
# conn.close()

import cx_Oracle
from numpy import record

conn = cx_Oracle.connect('python/python@localhost:1521/xe')
cs = conn.cursor()
rs = cs.execute("SELECT nvl(max(pan)+1,1)as maxpan from omok")

max_pan = 0
for record in rs:
    max_pan = int(record[0])
    
print(max_pan)
    
# cs.close()
conn.close()
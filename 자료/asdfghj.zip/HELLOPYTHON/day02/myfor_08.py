a = input("시작수:(큰수)")
b = input("끝수:(작은수)")

int_a = int(a)
int_b = int(b)
for i in range(int_b-1,int_a):
    print(str(int_a))
    int_a -= 1
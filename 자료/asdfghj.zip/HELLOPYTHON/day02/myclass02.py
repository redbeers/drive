from dask.array.random import power


class Dog:

    def __init__(self):
        self.power_bark1 = 0
        self.power_bark2 = 0
        self.power_bark3 = 0

    def teechFromHumen(self):
        self.power_bark1 += 1


class Bird(Dog):

#        부모꺼를 가지고온다.
# 무조건 써야하6는 기본식이다
    def __init__(self):
        Dog.__init__()
        self.power_fly = 0
        self.power_fly1 = 0
        self.power_fly2 = 0
        self.power_fly3 = 0
        
    def exercise(self, power):
        self.power_fly += power


if __name__ == '__main__':
    b = Bird()
    print(b.power_bark1)
    print(b.power_fly)
    b.teechFromHumen()
    b.exercise(5)
    print(b.power_bark1)
    print(b.power_fly)
    
#     ani = Animal()
#     print(ani.age)
#     ani.getold()
#     print(ani.age)
    

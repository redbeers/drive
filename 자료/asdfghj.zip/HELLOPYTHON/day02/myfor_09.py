arr = []

arr.append(0)
arr.append(1)
arr.append(2)
arr.append(4)
arr.insert(len(arr), 9)

print(arr)
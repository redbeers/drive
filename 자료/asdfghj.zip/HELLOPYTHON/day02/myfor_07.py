a = input("출력할 구구간은ex)2~9")

int_a = int(a)
for i in  range(1,10):
    sum = i*int_a
    print(a+"*"+str(i)+"="+str(sum))

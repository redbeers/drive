from dask.array.random import power


class Dog:

    def __init__(self):
        self.power_bark = 0

    def teechFromHumen(self):
        self.power_bark += 1


class Bird():

#        부모꺼를 가지고온다.
# 무조건 써야하6는 기본식이다
    def __init__(self):
        self.power_fly = 0
        
    def exercise(self, power):
        self.power_fly += power

class GaeSae(Dog,Bird):
    def __init__(self):
        Bird.__init__(self)
        Dog.__init__(self)
    
if __name__ == '__main__':
    gs = GaeSae()
    print(gs.power_bark)
    print(gs.power_fly)
    gs.exercise(4)
    gs.teechFromHumen()
    print(gs.power_bark)
    print(gs.power_fly)
    
#     ani = Animal()
#     print(ani.age)
#     ani.getold()
#     print(ani.age)
    

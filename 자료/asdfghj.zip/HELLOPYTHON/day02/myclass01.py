from dask.array.random import power
class Animal:
    def __init__(self):
        self.age = 1
    def getold(self):
        self.age+=1

class Human(Animal):
    def __init__(self):
#        부모꺼를 가지고온다.
        super().__init__() 
        self.power_lang = 1
        
    def learn_lang(self):
        self.power_lang+=1
        
    def gawe(self,power):
        self.power_lang += power

if __name__ == '__main__':
    hum = Human()
    print(hum.age)
    print(hum.power_lang)
    hum.getold()
    hum.learn_lang()
    hum.gawe(5)
    print(hum.age)
    print(hum.power_lang)
#     ani = Animal()
#     print(ani.age)
#     ani.getold()
#     print(ani.age)
    
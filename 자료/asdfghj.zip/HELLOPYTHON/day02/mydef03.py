def minus(a,b):
    return a-b

def add(a,b):
    return a+b

def mul(a,b):
    return a*b

def divide(a,b):
    return a/b

def res(a,b):
    return a%b
rest = res(1,2)
print(rest)
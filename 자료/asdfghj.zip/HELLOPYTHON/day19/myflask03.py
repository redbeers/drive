from flask import Flask, render_template

 
app  = Flask(__name__)
 
@app.route('/index')
def hello_name():
    list = ["호오옹","기이일","도오옹"]
    return render_template('index.html',list=list,str="대한민국",aat="aaa")

if __name__ == '__main__':
    app.run(debug=True)
from flask import Flask, render_template
import cx_Oracle


import cx_Oracle
import os

def getData():
    
    conn = cx_Oracle.connect('python/python@localhost:1521/xe')
    cur = conn.cursor()
    cur.execute("select * from sample")
    
    list = []
    
    for i in cur:
        list.append({'col01':i[0],'col02':i[1],'col03':i[2]})
        
    conn.close()
    return list

def myinsert(col01,col02,col03):
    conn = cx_Oracle.connect('python','python','localhost/xe')
    cs = conn.cursor()
    sql = "insert into sample (col01,col02,col03) values(:1, :2, :3)"
    cs.execute(sql,(col01,col02,col03))
    cnt = cs.rowcount
    cs.close()
    conn.commit()
    conn.close()
    return cnt
    
def myupdate(col01,col02,col03):
      
    conn = cx_Oracle.connect('python','python','localhost/xe')
    cs = conn.cursor()
    sql = "UPDATE sample SET col01=:1, col02=:2 ,col03=:3 where col01=:1"
    cs.execute(sql,(col01,col02,col03))
    cnt = cs.rowcount
    cs.close()
    conn.commit()
    conn.close()
    
    return cnt
def mydelete(col01):
    conn = cx_Oracle.connect('python','python','localhost/xe')
    cs = conn.cursor()
    sql = "DELETE sample WHERE col01=:1"
    cs.execute(sql,(col01,))
    cnt = cs.rowcount
    cs.close()
    conn.commit()
    conn.close()
    
    return cnt


 
app  = Flask(__name__)
 
@app.route('/sample')
def result():
    
    list = getData()
    
    return render_template('sample.html', list=list)

if __name__ == '__main__':
    app.run(debug=True)
    


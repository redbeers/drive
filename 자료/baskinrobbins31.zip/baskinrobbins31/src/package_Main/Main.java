package package_Main;

public class Main {
	public static void main(String[] args) {
		View view = new View();
		view.startMethod();
		System.out.println("┌≫≫≫≫≫≫≫≫≫≫≫≫≫≫≫≫≫≫≫≫┐");
		System.out.println("∮            Baskinrobbins31   ∮");
		System.out.println("└≪≪≪≪≪≪≪≪≪≪≪≪≪≪≪≪≪≪≪≪┘");
		System.out.println();
		System.out.println("이용해주셔서 감사합니다.");
	}
}
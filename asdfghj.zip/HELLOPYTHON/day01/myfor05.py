sum = 0
for i in range(1,101):
    if i%3 == 0:
        sum +=i
        print(str(i)+":번")
        print(sum)
        print("=======")

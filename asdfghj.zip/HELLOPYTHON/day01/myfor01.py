a = range(1,5)

print(a[3])
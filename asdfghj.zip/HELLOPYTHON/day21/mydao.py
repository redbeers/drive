import cx_Oracle

class MyDao:
    def __init__(self):
        self.conn = cx_Oracle.connect('python/python@localhost:1521/xe')
        self.cs= self.conn.cursor()
        print("생성자")

    def myselect(self):
        print("myselect")
        rs = self.cs.execute("select col01,col02,col03 from sample")
        list = []
        for i in rs:
            list.append({'col01':i[0],'col02':i[1],'col03':i[2]})
        return list
    
    def myinsert(self,col01,col02,col03):
        print("myinsert")
        sql = "insert into sample (col01,col02,col03) values(:1, :2, :3)"
        self.cs.execute(sql,(col01,col02,col03))
        cnt = self.cs.rowcount
        
        return cnt
        
    def myupdate(self,col01,col02,col03):
        sql = "UPDATE sample SET col02=:1 ,col03=:2 where col01=:3"
        self.cs.execute(sql,(col02,col03,col01))
        cnt = self.cs.rowcount
        
        return cnt        
        print("myupdate")
    def mydelete(self,col01):
        sql = "DELETE sample WHERE col01=:1"
        self.cs.execute(sql,(col01,))
        cnt = self.cs.rowcount
        
        return cnt
        print("mydelete")
    
    def __del__(self):
        self.conn.commit()
        self.cs.close()
        self.conn.close()
        
if __name__ == '__main__':
    dao = MyDao()
    list = dao.myselect()
#insert
#     cnt = dao.myinsert('2', '2', '2')
#update
#     cnt = dao.myupdate('2', '1', '2')
#delete
    cnt = dao.mydelete('1')
    
    print(list)
    print(cnt)
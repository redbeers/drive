# import cx_Oracle
# 
# conn = cx_Oracle.connect('python/python@localhost:1521/xe')
# cs = conn.cursor()
# cs.execute("insert into sample (col01,col02,col03) values ('6','6','6')")
# 
# # for i in cs:
# #     print(i[0])
# 
# cs.close()
# conn.commit()
# conn.close()

import cx_Oracle
import os
import time
os.putenv('NLS_LANG', '.UTF8')
start = time.time()
conn = cx_Oracle.connect('python','python','localhost/xe')
cs = conn.cursor()
for i in range(100000):
    sql = "insert into sample (col01,col02,col03) values(:1, :2, :3)"
    cnt = cs.execute(sql,('8','8','8'))
print(cnt)
print("time :", time.time() - start)
cs.close()
conn.commit()
conn.close()
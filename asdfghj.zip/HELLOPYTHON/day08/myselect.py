# import cx_Oracle
# 
# conn = cx_Oracle.connect('python/python@localhost:1521/xe')
# cs = conn.cursor()
# cs.execute("select col01,col02,col03 from sample ")
# 
# 
# for i in cs:
#     print(i[0])
# 
# cs.close()
# conn.close()

import cx_Oracle

conn = cx_Oracle.connect('python/python@localhost:1521/xe')

cur = conn.cursor()

cur.execute("select * from omok")

for i in cur:
    print(i)
    
# cs.close()
conn.close()
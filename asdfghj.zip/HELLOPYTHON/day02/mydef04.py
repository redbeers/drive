def minmuldiv(a,b):
    return a-b,a*b,a/b,a%b

min,mul,div,rest = minmuldiv(1,2)

print(min)
print(mul)
print(div)
print(rest)
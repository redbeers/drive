def add(a,b):
    return a+b

sum = add(1,2)
print(sum)
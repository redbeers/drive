import sys
import cx_Oracle
import os

from PyQt5 import uic, QtGui
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from asyncio.tasks import sleep
from conda.common._logic import TRUE
import cx_Oracle


form_class = uic.loadUiType("myomok02.ui")[0]



def getMax():
    conn = cx_Oracle.connect('python/python@localhost:1521/xe')
    cs = conn.cursor()
    rs = cs.execute("SELECT nvl(max(pan)+1,1)as maxpan from omok")
    max_pan = 0
    for record in rs:
        max_pan = int(record[0])
    conn.commit()
    conn.close()
    return max_pan


def writeHistory(pan,history,win):
    conn = cx_Oracle.connect('python','python','localhost/xe')
    cs = conn.cursor()
    
    
    sql = "insert into omok(pan,pseq,history,win) values(:1, :2, :3, :4)"
    
    for i,h in enumerate(history):
        cs.execute(sql,(pan,i,h,win))



    cs.close()
    conn.commit()
    conn.close()
    
class WindowClass(QMainWindow, form_class):
    
    
    def __init__(self):
        
        self.myselect()
        
        super().__init__()
        self.history = []
        self.setupUi(self)
        self.flag_wb = True
        self.flag_ing = True
        self.pb1.clicked.connect(self.myreset)
        self.pb2d = []
        self.arr2d = [
                [0,0,0,0,0, 0,0,0,0,0],
                [0,0,0,0,0, 0,0,0,0,0],
                [0,0,0,0,0, 0,0,0,0,0],
                [0,0,0,0,0, 0,0,0,0,0],
                [0,0,0,0,0, 0,0,0,0,0],
                
                [0,0,0,0,0, 0,0,0,0,0],
                [0,0,0,0,0, 0,0,0,0,0],
                [0,0,0,0,0, 0,0,0,0,0],
                [0,0,0,0,0, 0,0,0,0,0],
                [0,0,0,0,0, 0,0,0,0,0]
                
        ]
        for i in range(10):
            line = []
            for j in range(10):
                temp = QPushButton("", self)
                temp.setIcon(QIcon('0.png'))
                temp.setGeometry(j*40, i*40, 40, 40)
                temp.setIconSize(QSize(40,40))
                temp.setToolTip(str(i)+','+str(j))
                temp.clicked.connect(self.myclick)
                line.append(temp)
            self.pb2d.append(line)
        self.myrender()
        
    def myreset(self):
        self.flag_wb = True
        self.flag_ing = True
        for i in range(10):
            for j in range(10):
                self.arr2d[i][j] = 0
        self.history.clear()
        self.myrender()
        
           
    def myrender(self):
        for i in range(10):
            for j in range(10):
                if self.arr2d[i][j] == 0:
                    self.pb2d[i][j].setIcon(QIcon('0.png'))
                if self.arr2d[i][j] == 1:
                    self.pb2d[i][j].setIcon(QIcon('1.png'))
                if self.arr2d[i][j] == 2:
                    self.pb2d[i][j].setIcon(QIcon('2.png'))

    def myclick(self):
        if self.flag_ing == False:
            return
        
        str_ij = self.sender().toolTip()
        arr_ij = str_ij.split(',')
        int_i = int(arr_ij[0])
        int_j = int(arr_ij[1])
        
        if self.arr2d[int_i][int_j] > 0:
            return
        int_stone = 0
        if self.flag_wb:    
            self.arr2d[int_i][int_j] = 1
            int_stone = 1
        else:
            self.arr2d[int_i][int_j] = 2
            int_stone = 2
            
        up = self.getUP(int_i,int_j, int_stone)
        dw = self.getDW(int_i,int_j, int_stone)
        
        le = self.getLE(int_i,int_j, int_stone)
        rl = self.getRL(int_i,int_j, int_stone)
         
        ul = self.getUL(int_i,int_j, int_stone)
        dl = self.getDL(int_i,int_j, int_stone)
        
        ur = self.getUR(int_i,int_j, int_stone)
        pr = self.getPR(int_i,int_j, int_stone)
        
        self.myrender()
        
        str100 = ""
        
        for i in range(10):
            for j in range(10):
                str100+=str(self.arr2d[i][j])
        print(str100)
        self.history.append(str100)
        d1 = up + dw + 1
        d2 = le + rl + 1
        d3 = ul + pr + 1
        d4 = ur + pr + 1
       
        self.myrender()
        
        
       
        if d1 == 5 or d2 == 5 or d3 == 5 or d4 == 5:
            self.flag_ing = False
            win = 0
            if self.flag_wb:
                QMessageBox.about(self, "Title", "백돌 승")
                win = 1
            else:
                win = 2
                QMessageBox.about(self, "Title", "흑돌 승")
       
            max_pan = getMax()
            writeHistory(max_pan, self.history, win)
            
        self.flag_wb = not self.flag_wb
    
    def getUP(self,int_i,int_j, int_stone):
        cut = 0
        try:
            while True:
                int_i -= 1
                if int_i < 0:
                    return cut
                if self.arr2d[int_i][int_j] == int_stone:
                    cut +=1
                else:
                    return cut
        except:
            return cut
    
    def getDW(self,int_i,int_j, int_stone):
        cut = 0
        try:
            while True:
                int_i += 1
                if int_i < 0:
                    return cut
                if self.arr2d[int_i][int_j] == int_stone:
                    cut +=1
                else:
                    return cut
        except:
            return cut
# 왼쪽
    def getLE(self,int_i,int_j, int_stone):
        cut = 0
        try:
            while True:
                int_j -= 1
                if int_j < 0:
                    return cut
                if self.arr2d[int_i][int_j] == int_stone:
                    cut +=1
                else:
                    return cut
        except:
            return cut
# 오른쪽   
    def getRL(self,int_i,int_j, int_stone):
        cut = 0
        try:
            while True:
                int_j += 1
                if int_j < 0:
                    return cut
                if self.arr2d[int_i][int_j] == int_stone:
                    cut +=1
                else:
                    return cut
        except:
            return cut 
# 왼쪽위   
    def getUL(self,int_i,int_j, int_stone):
        cut = 0
        try:
            while True:
                int_i -= 1
                int_j -= 1
                if int_i < 0:
                    return cut
                if self.arr2d[int_i][int_j] == int_stone:
                    cut +=1
                else:
                    return cut
        except:
            return cut   
# 왼쪽 아래  
    def getDL(self,int_i,int_j, int_stone):
        cut = 0
        try:
            while True:
                int_i += 1
                int_j -= 1
                if int_i < 0:
                    return cut
                if self.arr2d[int_i][int_j] == int_stone:
                    cut +=1
                else:
                    return cut
        except:
            return cut 
# 오른쪽 위   
    def getUR(self,int_i,int_j, int_stone):
        cut = 0
        try:
            while True:
                int_i -= 1
                int_j += 1
                if int_i < 0:
                    return cut
                if self.arr2d[int_i][int_j] == int_stone:
                    cut +=1
                else:
                    return cut
        except:
            return cut 
# 오른쪽 아래   
    def getPR(self,int_i,int_j, int_stone):
        cut = 0
        try:
            while True:
                int_i += 1
                int_j += 1
                if int_i < 0:
                    return cut
                if self.arr2d[int_i][int_j] == int_stone:
                    cut +=1
                else:
                    return cut
        except:
            return cut 
# 오른쪽은 RL, 왼쪽 LE, 왼쪽위 UL, 왼쪽아래 DL, 오른쪽위 UR, 오른쪽 아래 PR
    def myselect(self):
        conn = cx_Oracle.connect('python/python@localhost:1521/xe')
        cur = conn.cursor()
        cur.execute("select * from omok")
        for i in cur:
            print(i)
        conn.close()
        
        
if __name__ == "__main__":
    app = QApplication(sys.argv) 
    myWindow = WindowClass() 
    myWindow.show()
    app.exec()
    

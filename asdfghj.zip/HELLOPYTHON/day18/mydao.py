import cx_Oracle



def getMax():
    conn = cx_Oracle.connect('python/python@localhost:1521/xe')
    cs = conn.cursor()
    rs = cs.execute("SELECT nvl(max(pan)+1,1)as maxpan from omok")
    max_pan = 0
    for record in rs:
        max_pan = int(record[0])
    conn.commit()
    conn.close()
    return max_pan


def writeHistory(pan,history,win):
    conn = cx_Oracle.connect('python','python','localhost/xe')
    cs = conn.cursor()
    
    
    sql = "insert into omok(pan,pseq,history,win) values(:1, :2, :3, :4)"
    
    for i,h in enumerate(history):
        cs.execute(sql,(pan,i,h,win))



    cs.close()
    conn.commit()
    conn.close()

# max_pan = getMax()
# print(max_pan)

history = [0,2]
pan = 1
win = 2

writeHistory(pan, history, win)
import sys
from PyQt5.QtWidgets import *
from PyQt5 import uic
from conda.gateways.disk.update import rename

form_class = uic.loadUiType("Myqt07.ui")[0]

class WindowClass(QMainWindow, form_class) :
    def __init__(self) :
        super().__init__()
        self.setupUi(self)
        self.pb1.clicked.connect(self.myclick)
        self.pb2.clicked.connect(self.myclick)
        self.pb3.clicked.connect(self.myclick)
        self.pb4.clicked.connect(self.myclick)
        self.pb5.clicked.connect(self.myclick)
        self.pb6.clicked.connect(self.myclick)
        self.pb7.clicked.connect(self.myclick)
        self.pb8.clicked.connect(self.myclick)
        self.pb9.clicked.connect(self.myclick)
    
    def myclick(self):
        dan = int(self.sender().text())
        a = ""
        for i in range(1,10):
            a += str(dan)+"*"+str(i)+"="+str(dan*i)+"\n"
            
        self.te.setText(a)

        

        
if __name__ == "__main__" :
    app = QApplication(sys.argv) 
    myWindow = WindowClass() 
    myWindow.show()
    app.exec()
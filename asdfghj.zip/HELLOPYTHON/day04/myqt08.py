import sys
from PyQt5.QtWidgets import *
from PyQt5 import uic
import random

form_class = uic.loadUiType("Myqt08.ui")[0]

class WindowClass(QMainWindow, form_class) :
    def __init__(self) :
        super().__init__()
        self.setupUi(self)
        self.pb.clicked.connect(self.myclick)
       
    
    def myclick(self):
        mine = self.le1.text()
        com = ""
        result = ""
        r = random.random()
        if r > 0.5:
            com = "홀"
        else:
            com = "짝"
        
        
        if mine == com:
            result = "승"
        else:
            result = "패"
        
        self.le2.setText(com)
        self.le3.setText(result)

        
if __name__ == "__main__" :
    app = QApplication(sys.argv) 
    myWindow = WindowClass() 
    myWindow.show()
    app.exec()
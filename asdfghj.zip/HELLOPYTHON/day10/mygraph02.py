import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import axes3d, Axes3D  
import cx_Oracle
from astropy.units import zs

conn = cx_Oracle.connect('python/python@localhost:1521/xe')
cur = conn.cursor()
cur.execute("SELECT cprice FROM stock  WHERE s_name='셀트리온'")
fig = plt.figure()
 
ax = fig.gca(projection='3d')  
ax.set_zlabel('z')
ax.set_xlabel('x')
ax.set_ylabel('y')
  
x = [10,10,10,10,10,10,10,10,10,10]
y = [0,1,2,3,4,5,6,7,8,9]
z = []
z2 = []  
z3 = []

for i in cur:
    z.append(i[0])
print(z)
cur.execute("SELECT cprice FROM stock  WHERE s_name='LG전자'")

for i in cur:
    z2.append(i[0])
print(z2)
cur.execute("SELECT cprice FROM stock  WHERE s_name='SK'")

for i in cur:
    z3.append(i[0])
print(z3)

ax.plot(x, y, z)
ax.plot(x+1, y, z2)
ax.plot(x+2, y, z3)

plt.show()

cur.close()
conn.close()
import numpy as np


arr_1 = np.ones((2,5))
arr_2 = np.reshape(arr_1,(5,2))



print(arr_1)
print(arr_2)

import sys

from PyQt5 import uic, QtGui
from PyQt5.QtGui import QIcon
from PyQt5.QtWidgets import *


form_class = uic.loadUiType("myomok01.ui")[0]


class WindowClass(QMainWindow, form_class):

    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.pb1.clicked.connect(self.myclick)
        self.pb1.count = 0
#         self.mystate = 0
    def myclick(self):
        self.sender().count += 1
        i = self.sender().count % 3
        self.sender().setIcon(QIcon(str(i) + ".png"))
        
#         if self.mystate == 0:
#             self.mystate = 1
#         elif self.mystate == 1:
#             self.mystate = 2
#         else :
#             self.mystate = 0
#             
#         pm = QtGui.Qpixmap(str(self.mystate)+".png");
#         self.pb.setIxon(QtGui.QIcon(pm))
        
#         self.pb1.setIcon(QIcon(str(a)+".png"))
        
#         elif a == 3:
#             a = 0
#         if b == 2:
#         b = 0
#         self.pb1.setIcon(QIcon(str(b)+".png"))
#             
#         b =+1
#         self.pb1.setIcon(QIcon(""))
#         self.pb1.setIcon(QIcon("1.png"))
        

if __name__ == "__main__":
    app = QApplication(sys.argv) 
    myWindow = WindowClass() 
    myWindow.show()
    app.exec()

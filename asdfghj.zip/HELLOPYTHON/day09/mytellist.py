import requests 
URL = 'http://localhost:7070/HelloWeb/tel_list.jsp' 
response = requests.get(URL) 
print(response.status_code)
print(response.text)




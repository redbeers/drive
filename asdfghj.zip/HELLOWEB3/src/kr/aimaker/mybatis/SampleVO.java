package kr.aimaker.mybatis;

public class SampleVO {
	private String col01;
	private String col02;
	private String col03;
	
	public String getCol01() {
		return col01;
	}
	public void setCol01(String col01) {
		this.col01 = col01;
	}
	public String getCol02() {
		return col02;
	}
	public void setCol02(String col02) {
		this.col02 = col02;
	}
	public String getCol03() {
		return col03;
	}
	public void setCol03(String col03) {
		this.col03 = col03;
	}
}

# import cx_Oracle
# 
# conn = cx_Oracle.connect('python/python@localhost:1521/xe')
# cs = conn.cursor()
# cs.execute("insert into sample (col01,col02,col03) values ('6','6','6')")
# 
# # for i in cs:
# #     print(i[0])
# 
# cs.close()
# conn.commit()
# conn.close()

import cx_Oracle
import os
os.putenv('NLS_LANG', '.UTF8')
  
conn = cx_Oracle.connect('python','python','localhost/xe')
cs = conn.cursor()
sql = "UPDATE sample SET col01=:1, col02=:2 ,col03=:3 where col01=:4"
cs.execute(sql,('3','3','3','12'))
print(cs.rowcount)
cs.close()
conn.commit()
conn.close()


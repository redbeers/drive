# import cx_Oracle
# 
# conn = cx_Oracle.connect('python/python@localhost:1521/xe')
# cs = conn.cursor()
# cs.execute("insert into sample (col01,col02,col03) values ('6','6','6')")
# 
# # for i in cs:
# #     print(i[0])
# 
# cs.close()
# conn.commit()
# conn.close()

import cx_Oracle
import os
os.putenv('NLS_LANG', '.UTF8')
  
conn = cx_Oracle.connect('python','python','localhost/xe')
cs = conn.cursor()
sql = "DELETE sample WHERE col01=:1"
cs.execute(sql,('5'))
print(cs.rowcount)
cs.close()
conn.commit()
conn.close()
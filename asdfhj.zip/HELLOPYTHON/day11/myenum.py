arr = ["홍길동","전우치","이순신"]

for i,item in enumerate(arr):
    print(i,item)
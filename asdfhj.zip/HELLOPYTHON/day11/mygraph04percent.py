import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import axes3d, Axes3D  
import cx_Oracle
from astropy.units import zs
import numpy as np

conn = cx_Oracle.connect('python/python@localhost:1521/xe')
cur = conn.cursor()
    
def getCprice(s_name):
    cur.execute("SELECT cprice FROM stock WHERE s_name='"+s_name+"'order by in_time")
    
    ret = []
    for record in cur:
        ret.append(record[0])
        
    return ret

def getSname():
    cur.execute("select s_name from stock GROUP by s_name")
    
    ret = []
    for record in cur:
        ret.append(record[0])
        

    return ret
 
fig = plt.figure()
ax = fig.gca(projection='3d')  
ax.set_zlabel('z')
ax.set_xlabel('x')
ax.set_ylabel('y')
  
s_names = getSname()
# s_names = ["삼성전자","LG"] 

cnt = len(getCprice("삼성전자"))
y = range(cnt)
x = np.zeros(cnt)
    
for i,s_name in enumerate(s_names):
    
    z = np.array(getCprice(s_name))
    z_init = z[0]
    print(z)
    if z_init == 0:
        continue
    z = (z/z_init)*100
    ax.plot(x+i, y, z)
    

plt.show()
cur.close()
conn.close()

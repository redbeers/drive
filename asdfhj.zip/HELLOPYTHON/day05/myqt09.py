import sys
from PyQt5.QtWidgets import *
from PyQt5 import uic
import random

form_class = uic.loadUiType("Myqt09.ui")[0]

class WindowClass(QMainWindow, form_class) :
    def __init__(self) :
        super().__init__()
        self.setupUi(self)
        self.pb.clicked.connect(self.myclick)
       
    
    def myclick(self):
        mine = self.le1.text()
        rnd = random.random()
        com = ""
        if rnd < 0.3:
            com = "가위"
        elif rnd < 0.6:
            com = "바위"
        else:
            com = "보"  
              
        result = ""
        if com == mine:
            result = "비김"
        elif com == "바위" and mine == "보" or com == "가위" and mine == "바위" or com == "보" and mine == "가위":
            result = "이김"
        else:
            result = "짐"
        
        self.le2.setText(com)
        self.le3.setText(result)

        
if __name__ == "__main__" :
    app = QApplication(sys.argv) 
    myWindow = WindowClass() 
    myWindow.show()
    app.exec()
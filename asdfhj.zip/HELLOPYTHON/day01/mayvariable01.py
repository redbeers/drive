a = 3.3
b = True
c = 'good'

print(str(a)+c)
print(b and True)
print(c)

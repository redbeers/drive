def minus(a,b):
    return a-b

def add(a,b):
    return a+b

min = minus(1,2)
print(min)
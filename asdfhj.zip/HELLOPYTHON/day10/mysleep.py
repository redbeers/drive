import time



print ("Sleep 5 seconds from now on...")

t = time.sleep(60)

print("wake up!")
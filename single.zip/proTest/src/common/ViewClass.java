package common;

import admin.IAdminIService;
import admin.IAdminIServiceImpl;
import icecream.IIcecreamService;
import icecream.IIcecreamServiceImpl;
import notify.INotifyIService;
import notify.INotifyIServiceImpl;
import orderDetails.IOrderDetailsIService;
import orderDetails.IOrderDetailsIServiceImpl;
import orderInformation.IOrderInformationService;
import orderInformation.IOrderInformationServiceImpl;
import size.ISizeService;
import size.ISizeServiceImpl;
import user.IUserService;
import user.IUserServiceImpl;

public class ViewClass {
	private IUserService memService = IUserServiceImpl.getInstance();
	private ISizeService sizeService = ISizeServiceImpl.getInstance();
	private IOrderInformationService orderInfoService = IOrderInformationServiceImpl.getInstance();
	private IOrderDetailsIService orderDetailService = IOrderDetailsIServiceImpl.getInstance();
	private INotifyIService notifyService = INotifyIServiceImpl.getInstance();
	private IIcecreamService icecreamService = IIcecreamServiceImpl.getInstance();
	private IAdminIService adminIService = IAdminIServiceImpl.getInstance();
	
	public void startMethod() {
		
	}
}

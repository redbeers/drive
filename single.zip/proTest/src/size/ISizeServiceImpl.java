package size;

public class ISizeServiceImpl implements ISizeService {

	private static ISizeServiceImpl service;
	private ISizeDao dao;
	
	private ISizeServiceImpl(){
		dao = ISizeDaoImpl.getInstance();
	}
	
	public static ISizeService getInstance(){
		if(service == null){
			service = new ISizeServiceImpl();
		}
		return service;
	}
}

package size;

import db.DBClass;

public class ISizeDaoImpl implements ISizeDao {
	
	private static ISizeDao dao;
	private DBClass db;
	
	private ISizeDaoImpl(){
		db = DBClass.getInstance();
	}
	
	public static ISizeDao getInstance(){
		if(dao == null){
			dao = new ISizeDaoImpl();
		}
		return dao;
	}
}

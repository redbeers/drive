package size;

public interface ISizeService {

}

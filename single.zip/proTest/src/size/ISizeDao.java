package size;

public interface ISizeDao {

}

package orderDetails;

public class IOrderDetailsIServiceImpl implements IOrderDetailsIService{
	private static IOrderDetailsIServiceImpl service;
	private IOrderDetailsDao dao;
	
	private IOrderDetailsIServiceImpl(){
		dao = IOrderDetailsDaoImpl.getInstance();
	}
	public static IOrderDetailsIService getInstance(){
		if(service == null){
			service = new IOrderDetailsIServiceImpl();
		}
		return service;
	}
}

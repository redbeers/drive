package orderDetails;

public interface IOrderDetailsDao {

}

package orderDetails;

import db.DBClass;

public class IOrderDetailsDaoImpl implements IOrderDetailsDao{
	private static IOrderDetailsDao dao;
	private DBClass db;
	
	private IOrderDetailsDaoImpl(){
		db = DBClass.getInstance();
	}
	public static IOrderDetailsDao getInstance(){
		if(dao == null){
			dao = new IOrderDetailsDaoImpl();
		}
		return dao;
	}
	
}

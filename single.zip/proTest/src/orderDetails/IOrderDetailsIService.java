package orderDetails;

public interface IOrderDetailsIService {

}

package admin;

public interface IAdminDao {

}

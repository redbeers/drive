package admin;

public interface IAdminIService {

}

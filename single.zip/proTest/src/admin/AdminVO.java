package admin;

public class AdminVO {
	private String id = "admin";
	private String pw = "p@ssW0rd";
	public String getId() {
		return id;
	}
	public String getPw() {
		return pw;
	}
}

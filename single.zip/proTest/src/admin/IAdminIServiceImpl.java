package admin;

public class IAdminIServiceImpl implements IAdminIService{
	private static IAdminIServiceImpl service;
	private IAdminDao dao;
	
	
	
	private IAdminIServiceImpl(){
		dao = IAdminDaoImpl.getInstance();
	}
	public static IAdminIService getInstance(){
		if(service == null){
			service = new IAdminIServiceImpl();
		}
		return service;
	}
}

package db;

import java.util.ArrayList;
import java.util.List;

import admin.AdminVO;
import icecream.IcecreamVO;
import notify.NotifyVO;
import orderDetails.OrderDetailsVO;
import orderInformation.OrderInformationVO;
import size.SizeVO;
import user.UserVO;

public class DBClass {
	
	private static DBClass db;
	private DBClass(){
		
	}
	
	public static DBClass getInstance() {
		if(db == null){
			db = new DBClass();
		}
		return db;
	}
	
	private List<UserVO> userList = new ArrayList<>();
	private AdminVO admin = new AdminVO();
	private List<NotifyVO> notifyList = new ArrayList<NotifyVO>();
	private List<IcecreamVO> icecreamList = new ArrayList<IcecreamVO>();
	private List<SizeVO> sizeList = new ArrayList<>();
	private List<OrderInformationVO> orderInformationList = new ArrayList<>();
	private List<OrderDetailsVO> orderDetailsList = new ArrayList<>();
	
}

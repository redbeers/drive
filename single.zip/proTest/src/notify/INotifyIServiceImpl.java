package notify;

public class INotifyIServiceImpl implements INotifyIService{

	private static INotifyIServiceImpl service;
	private INotifyDao dao;
	
	private INotifyIServiceImpl(){
		dao = INotifyDaoImpl.getInstance();
	}
	public static INotifyIService getInstance(){
		if(service == null){
			service = new INotifyIServiceImpl();
		}
		return service;
	}
	
}

package notify;

public interface INotifyIService {
	
}

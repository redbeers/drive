package notify;

public interface INotifyDao {

}

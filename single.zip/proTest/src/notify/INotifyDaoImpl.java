package notify;

import db.DBClass;

public class INotifyDaoImpl implements INotifyDao{
	private static INotifyDao dao;
	private DBClass db;
	
	private INotifyDaoImpl(){
		db = DBClass.getInstance();
	}
	public static INotifyDao getInstance(){
		if(dao == null){
			dao = new INotifyDaoImpl();
		}
		return dao;
	}

}

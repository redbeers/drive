package user;

public interface IUserDao {

}

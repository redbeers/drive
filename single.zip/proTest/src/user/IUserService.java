package user;

public interface IUserService {

}

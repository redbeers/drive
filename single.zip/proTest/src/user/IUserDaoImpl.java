package user;

import db.DBClass;

public class IUserDaoImpl implements IUserDao{

	private static IUserDao dao;
	private DBClass db;
	
	private IUserDaoImpl(){
		db = DBClass.getInstance();
	}
	
	public static IUserDao getInstance() {
		if(dao == null){
			dao = new IUserDaoImpl();
		}
		return dao;
	}

}

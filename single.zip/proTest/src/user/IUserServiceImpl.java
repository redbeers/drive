package user;

public class IUserServiceImpl implements IUserService{
	
	private static IUserServiceImpl service;
	private IUserDao dao;
	
	private IUserServiceImpl(){
		dao = IUserDaoImpl.getInstance();
	}

	public static IUserService getInstance() {
		if(service == null){
			service = new IUserServiceImpl();
		}
		return service;
	}
}

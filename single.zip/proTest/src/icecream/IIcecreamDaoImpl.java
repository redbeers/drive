package icecream;

import db.DBClass;

public class IIcecreamDaoImpl implements IIcecreamDao{
	private static IIcecreamDao dao;
	private DBClass db;
	
	private IIcecreamDaoImpl(){
		db = DBClass.getInstance();
	}
	public static IIcecreamDao getInstance(){
		if(dao == null){
			dao = new IIcecreamDaoImpl();
		}
		return dao;
	}
}

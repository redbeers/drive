package icecream;

public interface IIcecreamDao {

}

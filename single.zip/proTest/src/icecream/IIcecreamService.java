package icecream;

public interface IIcecreamService {

}

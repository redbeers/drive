package icecream;

public class IIcecreamServiceImpl implements IIcecreamService{
	private static IIcecreamServiceImpl service;
	private IIcecreamDao dao;
	
	private IIcecreamServiceImpl(){
		dao = IIcecreamDaoImpl.getInstance();
	}
	
	public static IIcecreamService getInstance(){
		if(service == null){
			service = new IIcecreamServiceImpl();
		}
		return service;
	}
}

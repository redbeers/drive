package orderInformation;

import db.DBClass;

public class IOrderInformationDaoImpl implements IOrderInformationDao{

	private static IOrderInformationDao dao;
	private DBClass db;
	
	public static IOrderInformationDao getInstance() {
		if(dao == null){
			dao = new IOrderInformationDaoImpl();
		}
		return dao;
	}

}

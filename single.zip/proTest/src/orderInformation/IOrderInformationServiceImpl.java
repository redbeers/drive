package orderInformation;

public class IOrderInformationServiceImpl implements IOrderInformationService{
	private static IOrderInformationService service;
	private IOrderInformationDao dao;
	
	private IOrderInformationServiceImpl(){
		dao = IOrderInformationDaoImpl.getInstance();
	}
	
	public static IOrderInformationService getInstance(){
		if(service == null){
			service = new IOrderInformationServiceImpl();
		}
		return service;
	}
}

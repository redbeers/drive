package orderInformation;

public interface IOrderInformationService {
	
	
}

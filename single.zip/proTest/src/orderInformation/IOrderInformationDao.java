package orderInformation;

public interface IOrderInformationDao {

}

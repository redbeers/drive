package package_VO;

public class AdminVO {
	public String getId() {
		return "admin";
	}
	public String getPw() {
		return "p@ssW0rd";
	}
}

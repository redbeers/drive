package shoplist;

public class Certify {
	
	private int num;
	private String c_id;
	private int c_birthday;
	
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public String getC_id() {
		return c_id;
	}
	public void setC_id(String c_id) {
		this.c_id = c_id;
	}
	public int getC_birthday() {
		return c_birthday;
	}
	public void setC_birthday(int c_birthday) {
		this.c_birthday = c_birthday;
	}
	

}

package shoplist;

//장바구니
public class ShopListVO {
	private int seq;//장바구니 고유번호 pk
	private String c_id;//손님 아이디fk
	private String p_id;//재고 아이디fk
	private int mount;//장바구니 물건 수량
	
	public int getSeq() {
		return seq;
	}
	public void setSeq(int seq) {
		this.seq = seq;
	}
	public String getC_id() {
		return c_id;
	}
	public void setC_id(String c_id) {
		this.c_id = c_id;
	}
	public String getP_id() {
		return p_id;
	}
	public void setP_id(String p_id) {
		this.p_id = p_id;
	}
	public int getMount() {
		return mount;
	}
	public void setMount(int mount) {
		this.mount = mount;
	}
	@Override
	public String toString() {//재품, 재품 수량 확인
		return " p_id=" + p_id + ", mount=" + mount ;
	}
	
	
}

package package_Database;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import package_VO.AdminVO;
import package_VO.CustomerVO;
import package_VO.ProductVO;

public class Database {

	public static int snack_seq = 2;

	private final AdminVO admin = new AdminVO();
	// admin 계정
	
	private final List<CustomerVO> customerList = new ArrayList<>();
	// 손님 목록
	

	private final List<ProductVO> proList = new ArrayList<>();
	//상품리스트
	
	
	/**
	 * <code>insertUser</code> 메서드는 새로운 사용자를 추가하기 위한 메서드입니다.
	 * 
	 * @param Customer
	 *            : 추가할 CustomerVO 객체
	 * @return 추가에 성공한다면 true, 실패한다면 false 반환
	 * @author 
	 */
	public boolean insertUser(CustomerVO customer) {
		return customerList.add(customer);
	}
	/**
	 * <code>userIdUniqueCheck</code> 메서드는 입력한 id가 유일한 값이 맞는지 판별하는 메서드입니다.
	 * 
	 * @param userId
	 *            : 유효성을 확인하기 위한 String 객체
	 * @return 유일한 값이라면 true, 그렇지 않은 경우라면 false 반환
	 */
	public boolean userIdUniqueCheck(String userId) {
		if (admin.getId().equals(userId)) {
			return false;
		}
		return selectCustomer(userId) == null;
	}
	/**
	 * <code>adminLogin</code> 메서드는 해당 로그인 요청이 관리자 계정과 일치하는지 판별하는 메서드입니다.
	 * 
	 * @param loginInfo
	 *            : user_id, user_pw를 담은 Map
	 * @return 로그인에 성공한다면 true, 그렇지 않다면 false.
	 * @author
	 */
	public boolean adminLogin(Map<String, String> loginInfo) {
		return admin.getId().equals(loginInfo.get("user_id"))
				&& admin.getPw().equals(loginInfo.get("user_pw"));
	}

	/**
	 * <code>selectAllUser</code> 메서드는 모든 유저의 정보를 불러오기 위한 메서드입니다.
	 * 
	 * @return 모든 유저의 정보를 포함한 List
	 * @author
	 */
	public List<CustomerVO> selectAllUser() {
		List<CustomerVO> userList = new ArrayList<>();
		for (CustomerVO user : this.customerList) {
			userList.add(user);

		}
		return userList;
	}

	/**
	 * <code>selectUser</code> 메서드는 선택한 유저의 정보를 불러오기 위한 메서드입니다.
	 * 
	 * @param id
	 *            : 사용자의 고유 id
	 * @return 사용자의 정보를 담고 있는 UserVO 객체
	 * @author 
	 */
	public CustomerVO selectCustomer(String id) {
		for (CustomerVO user : customerList) {
			if (user.getCustomerID().equals(id)) {
				return user;
			}
		}
		return null;
	}

	/**
	 * <code>userLogin</code> 메서드는 해당 로그인 요청이 사용자 계정과 일치하는지 판별하는 메서드입니다.
	 * 
	 * @param loginInfo
	 *            : user_id, user_pw를 담은 Map
	 * @return 로그인에 성공한다면 true, 그렇지 않다면 false.
	 * @author 
	 */
	public boolean userLogin(Map<String, String> loginInfo) {
		if (selectCustomer(loginInfo.get("user_id")) == null) {
			return false;
		}
		return selectCustomer(loginInfo.get("user_id")).getPassword().equals(
				loginInfo.get("user_pw"));
		// && selectUser(loginInfo.get("user_id")).isActivate();
	}
	//////////////////////////////////////

	//CRUD 중 R!!!
	public List<ProductVO> selectAllProduct(){
		
//		for (ProductVO productList1 : this.proList) {
//			
//			if(productList1.isActivate()){
//				
//				productList.add(productList1);
//			}
//		}
//		return productList;
		return proList;
	}

	
	/**
	 * insertProduct 메서드는 새로운 상품을 추가하기 위한 메서드입니다.
	 * 
	 * @param product
	 *            : 추가할 ProductVO 객체
	 * @return 추가에 성공하면 true, 실패하면 false 반환
	 * @author 성원제
	 */
	public boolean insertProduct(ProductVO productVO) {
		return proList.add(productVO);
	}
	
	
///////////////////////
	//////////////////////////////////////////////
	{
		ProductVO prod1 = new ProductVO();
		prod1.setPro_seq(1);
		prod1.setName("새우깡");
		prod1.setPrice(1000);
		prod1.setStock(100);
		proList.add(prod1);
	
		ProductVO prod2 = new ProductVO();
		prod2.setPro_seq(2);
		prod2.setName("포카칩");
		prod2.setPrice(1000);
		prod2.setStock(500);
		proList.add(prod2);
	}
	/////////////////////////////////////
	// CustomerVO 초기화 블럭
		{
			CustomerVO user1 = new CustomerVO();
			user1.setCustomerID("1");
			user1.setPassword("1");
			user1.setName("길민선");
			customerList.add(user1);

		}
}


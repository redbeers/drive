package package_Main;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import package_Database.Database;
import package_VO.CustomerVO;
import package_VO.ProductVO;

public class View {
	private CustomerVO customer = null;
	private final IServiceImpl iServiceImpl = new IServiceImpl();

	Scanner sc = new Scanner(System.in);
	Database db = new Database();

	// 숫자입력받기
	int iInput() {
		int input;
		while (true) {
			try {
				Scanner scanner = new Scanner(System.in);
				input = scanner.nextInt();
				break;
			} catch (Exception e) {
				System.out.println();
				System.out.println("숫자만 입력해주세요.");
			}
		}
		return input;
	}

	// 문자입력받기
	String sInput() {
		String sInput;
		while (true) {
			try {
				Scanner scanner = new Scanner(System.in);
				sInput = scanner.next();
				break;
			} catch (Exception e) {
				System.out.println();
				System.out.println("문자만 입력해주세요.");
			}
		}
		return sInput;
	}

	/**
	 * 
	 * @author
	 * @param
	 */

	void mainScreen() {
		String message = "";
		while (true) {
			System.out.println("메인화면");
			System.out.println();
			System.out.println("[ 1 ] 로그인");
			System.out.println("[ 2 ] 회원가입");
			System.out.println("[ 0 ] 종료");

			if (!"".equals(message)) {
				System.out.println();
				System.out.println(message);
				message = "";
			}

			switch (iInput()) {
			case 0:
				System.out.println("프로그램을 종료합니다.");
				return;
			case 1:
				login();
				break;
			case 2:
				// 회원가입;
				break;
			default:
				message = "잘못 입력하셨습니다. 다시 입력해 주세요.";
			}

		}

	}

	/**
	 * 로그인 뷰 -관리자/사용자 메서드 -아이디 비밀번호값을 받아 database에서 비교
	 * 
	 * @author
	 */
	// db
	// 아이디 비밀번호
	// 받아간다
	private void login() {
		String userId = null;
		String userPw = null;
		String message = "";

		while (true) {
			System.out.println();
			if (userId == null) {
				System.out.println("→ 1. 아이디 입력");
				System.out.println("2. 비밀번호 입력");
			} else if (userPw == null) {
				System.out.println("1. 아이디 입력");
				System.out.println("→ 2. 비밀번호 입력");
			}
			System.out.println();

			if (userId == null) {
				System.out.println("아이디를 입력하세요.");
				if (!"".equals(message)) {
					System.out.println();
					System.out.println(message);
					message = "";
				}
				userId = sInput();
				continue;
			} else if (userPw == null) {
				System.out.println("비밀번호를 입력하세요.");
				userPw = sInput();
				continue;
			}

			Map<String, String> loginInfo = new HashMap<>();
			loginInfo.put("user_id", userId);
			loginInfo.put("user_pw", userPw);

			if (iServiceImpl.adminLogin(loginInfo)) {
				adminMainView();
				break;
			} else if (iServiceImpl.userLogin(loginInfo)) {
				customer = iServiceImpl.selectCustomer(userId);
				userMainView();
				break;
			}

			message = "아이디 또는 비밀번호를 확인하세요.";
			userId = null;
			userPw = null;
		}
	}

	/**
	 * -관리자 메인 뷰 -관리자 메서드
	 * 
	 * @author
	 * 
	 */
	// 관리자 페이지 메뉴 보여주기
	private void adminMainView() {
		while (true) {
			System.out.println("관리자 페이지");
			System.out.println("[ 1 ] 상품리스트 관리");
			System.out.println("[ 2 ] 상품재고 관리");
			System.out.println("[ 3 ] 공지사항 관리");
			System.out.println("[ 0 ] 로그아웃");
			System.out.println();
			System.out.println("메뉴를 선택하세요.");

			switch (iInput()) {
			case 0:
				// 뒤로가기
				return;
			case 1:
				// 상품리스트 관리 메서드 호출
				adminProductView();
				break;
			case 2:
				// 상품재고 관리 메서드 호출
				adminStockView();
				break;
			case 3:
				// 공지사항 관리 메서드 호출
				adminNotifyView();
				break;
			default:
				System.out.println("잘못입력");
			}
		}
	}

	private void adminStockView() {
	}

	private void adminNotifyView() {

	}

	/**
	 * 관리자메인-[1]상품리스트
	 * 
	 * @author
	 * @param
	 */

	private void adminProductView() {
		while (true) {
			System.out.println("상품관리 화면");
			System.out.println("[1]리스트 보기 ");
			System.out.println("[0]이전");

			switch (iInput()) {
			case 0:
				return;
			case 1:
				productListView();// [1]상품리스트 보기
				break;
			case 2:
				// categoryView_product();// [2]젤리리스트보기
				break;
			case 3:
				// categoryView_product();//[3]젤리리스트보기
				break;
			default:
				System.out.println("잘못 입력하셨습니다. 다시 입력해 주세요.");
			}
		}
	}

	/**
	 * @author HOME
	 * @param
	 */
	private void productListView() {
		// db
		// List<ProductVO> selectAllProduct();
		// 상품 목록 불러와서 보기
		List<ProductVO> productlist = iServiceImpl.selectAllProduct();
		System.out.println(productlist);

		// 상품보기 목록을 보고 상품도 추가하기

		// 상품보기 목록을 보고 상품도 추가하기
		while (true) {
			System.out.println("[1] 상품추가하기");
			System.out.println("[0] 이전");

			switch (iInput()) {
			case 0:
				return;
			case 1:
				insertProductMethod();
				break;
			default:
				System.out.println("잘못 입력하셨습니다. 다시 입력해 주세요.");

			}

		}

	}

	// /////////////////상품추가하기/////////////////////////////////
	/**
	 * -상품 추가 - 관리자 메서드
	 * 
	 * @author 성원제1
	 */
	private void insertProductMethod() {
		System.out.println("=============================");
		System.out.println("상품 추가하기");
		System.out.println("=============================");

		System.out.println("추가할 상품의 이름을 입력해주세요");
		// 상품이름을 입력받는다
		String name = sInput();

		System.out.println("추가할 상품의 가격을 입력해주세요");
		// 상품의 가격을 입력한다.
		int price = iInput();

		System.out.println("추가할 상품의 재고를 입력해주세요");
		// 상품의 재고를 입력한다.
		int stock = iInput();

		ProductVO insertProduct = new ProductVO();

		// ProductVO 리스트에 새로운 제품 이름 추가
		insertProduct.setName(name);
		// ProductVO 리스트에 가격 추가
		insertProduct.setPrice(price);
		// ProductVO 리스트에 재고 추가
		insertProduct.setStock(stock);

		insertProduct.setPro_seq(++Database.snack_seq);

		if (iServiceImpl.insertProduct(insertProduct)) {
			System.out.println("추가되었습니다.");
		} else {
			System.out.println("추가에 실패하였습니다.");
		}
	}

	// /////////////////상품수정하기/////////////////////////////////
	private void removeProductMethod() {

	}

	// //////////////////////////////////////////회원뷰///////////////////////////////////
	/**
	 * -회원 메인 뷰 -사용자 메서드
	 * 
	 * @author
	 */
	private void userMainView() {

		String message = "";
		while (true) {
			if (customer == null) {
				return;
			}
			System.out.println("고객 페이지");
			System.out.println("--------------------");
			System.out.println("[ 1 ] 상품 리스트 보기");// userProductView();
			System.out.println("[ 2 ] 주문내역 보기");// userOrderedListView();
			System.out.println("[ 3 ] 공지사항 보기");// userNotifyView();
			System.out.println("[ 4 ] 마이페이지");// myPageView();
			System.out.println("[ 0 ] 로그아웃");
			System.out.println("--------------------");

			if (!"".equals(message)) {
				System.out.println();
				System.out.println(message);
				message = "￣￣￣￣￣￣￣￣￣￣￣￣￣￣";
			}

			switch (iInput()) {
			case 0:
				return;
			case 1:
				userProductView();
				break;
			case 2:
				userOrderedListView();
				break;
			case 3:
				userNotifyView();
				break;
			case 4:
				myPageView();
				break;
			default:
				message = "올바르지 않은 입력입니다.";
			}
		}
	}
	/**
	 * @param int 사용자가 입력한 번호
	 * @author 박상빈
	 * 
	 */
	//db
	//주문내역에 넣기 (아직안만든 리스트) 
	//포인트 차감해서 넣기 (아직안만든 리스트)
	//재고 줄열서 넣기 
	private void userProductView() {
		List<ProductVO> productlist = iServiceImpl.selectAllProduct();
		// 사용자가 과자 선택
		// int 로 받는다
		while (true) {
			System.out.println("상품 목록");
			System.out.println("[ 0 ] 이전");
			System.out.println(productlist);
			int selectNum = iInput();// 사용자 입력값
			if (selectNum == 0) {// 0입력시 이전화면
				return;
			}
			System.out.println("상품 번호를 입력해주세요");
			if (selectNum < productlist.size()) {
				System.out.println(selectNum + "선택");
				System.out.println(productlist.get(selectNum - 1).getName()+ "을 구입하였습니다.");
				// 주문내역에 넣기
				// 포인트 차감
				// 재고 줄이기

			} else {
				System.out.println("다시 입력 해주세요");
			}

		}

	}

	// 주문내역 보기
	private void userOrderedListView() {
		//주문 내역 들어있는 리스트 불러오기
		
	}

	// 공지사항
	private void userNotifyView() {
		//공지사항 목록 모두 불러오기
	}

	// 마이페이지
	private void myPageView() {
		//회원정보 모두 모두 보여주기
		
	}

}

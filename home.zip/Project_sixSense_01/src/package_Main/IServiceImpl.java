package package_Main;

import java.util.List;
import java.util.Map;

import package_Database.Database;
import package_VO.CustomerVO;
import package_VO.ProductVO;

public class IServiceImpl implements IService{
	Database db = new Database();

	@Override
	public List<ProductVO> selectAllProduct() {
		return db.selectAllProduct();
	}


	@Override
	public boolean insertProduct(ProductVO productVO) {
		return db.insertProduct(productVO);
	}


	/**
	 * 회원가입 - 유저 정보 DB에 입력
	 * 
	 * @param user
	 * @return 성공 시 true, 실패 시 false 반환
	 * @author 
	 */
	@Override
	public boolean insertUser(CustomerVO user) {
		return db.insertUser(user);
	}
	
	
	
	@Override
	public boolean checkId(String id) {
		return db.userIdUniqueCheck(id);
	}

	@Override
	public boolean adminLogin(Map<String, String> loginInfo) {
		return db.adminLogin(loginInfo);
	}

	@Override
	public boolean userLogin(Map<String, String> loginInfo) {
		return db.userLogin(loginInfo);
	}

	@Override
	public CustomerVO selectCustomer(String user_id) {
		return db.selectCustomer(user_id);
	}

	
	//////////////////////////////////

}

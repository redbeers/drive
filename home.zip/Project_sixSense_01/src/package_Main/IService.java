package package_Main;

import java.util.List;
import java.util.Map;

import package_VO.CustomerVO;
import package_VO.ProductVO;

public interface IService {
	
	/**
	 * @return 
	 * @param 리스트 다 불러오는 거니까 파라미터 없음
	 * @author 
	 * 
	 */
	List<ProductVO> selectAllProduct();
	
	boolean insertProduct(ProductVO productVO);
	/**
	 * 회원가입 - 유저 정보 DB에 입력
	 * 
	 * @param userVO
	 * @return 성공 시 true, 실패 시 false 반환
	 * @author 
	 */
	boolean insertUser(CustomerVO user);
	
	

	/**
	 * id 중복 여부와 조건을 충분히 만족하는지 확인
	 * 
	 * @param id
	 * @return 만족하면 true, 불만족하면 false 반환
	 */
	boolean checkId(String id);

	/**
	 * 관리자 계정 로그인
	 *
	 * @param loginInfo
	 * @return 로그인 성공 시 true, 실패 시 false 반환
	 */
	boolean adminLogin(Map<String, String> loginInfo);

	/**
	 * 회원 계정 로그인
	 * 
	 * @param loginInfo
	 *            <"user_id", user_id>, <"user_pw", user_pw> 키/값을 전송하여 로그인 성공여부
	 *            반환받음
	 * @return 로그인 성공 시 true, 실패 시 false 반환
	 * @author 
	 */
	boolean userLogin(Map<String, String> loginInfo);
	
	/**
	 * 선택한 유저 정보 가져오기 - 관리자 메서드
	 * 
	 * @param customerID
	 * @return SustomerVO
	 * @author 길민선
	 */
	CustomerVO selectCustomer(String user_id);
	
	
	
	/////////////////////////////////////

}

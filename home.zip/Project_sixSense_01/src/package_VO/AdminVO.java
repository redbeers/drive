package package_VO;

public class AdminVO {

	public String getId() {
		return "11";
	}
	public String getPw() {
		return "11";
	}
	
	

}

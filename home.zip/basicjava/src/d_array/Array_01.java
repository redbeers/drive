package d_array;

public class Array_01 {
	public static void main(String[] args) {
		/*
		 * 1.배열(Array)
		 * -같은 타입의 여러 변수를 하나의 묶음으로 다루는 것
		 *  int math;
		 *  int eng;
		 *  int soc;
		 *  
		 *  2.배열의 선언
		 *  -원하는 타입의 번수를 선언하고 변수 또는 타입에 배열임으 ㄹ의미하는 대괄호[]를 붙이면 된다.
		 *  -구조
		 *  변수타입[] 변수명; -> int[] score;
		 *  변수타입 변수명[];//사용안함 -> int score[];//기본형으로 실수 할 수 있다.
		 *  
		 *  3.배열의 생성->공간을 만든다
		 *  -배열의 생성하기 위해서는 연산자 'new'와 함께 배열이 타입과 크기를 지정해 주어야한다.
		 *  ex) score = new int[3]; >0으로 기본값으로 주어진다.
		 *  -배열은 한번 생성되면 크기를 변경할 수 없다.
		 *  
		 */
		
		int[] score = new int[5];// >{0,0,0,0,0}
//		System.out.println(score[0]);
//		System.out.println(score[1]);
//		System.out.println(score[2]);
//		System.out.println(score[3]);
//		System.out.println(score[4]);
//		
//		//0:5:1:System.out.println(score[0]);
//		for(int i=0; i<score.length; i++){
//			System.out.println(score[i]);
//		}
////		score[0] = 10;
////		score[1] = 20;
////		score[2] = 30;
////		score[3] = 40;
////		score[4] = 50;
//		//10:50:10:score [?] = (?+1)*10
//		for(int i=0; i<score.length; i++){
//			score[i] = (i+1)*10;
//			System.out.println(score[i]);
//		}
//		
//		//2.배열의 선언 및 초기화 원하는 값으로 하기
////		int[] score2 = new int[] {10,20,30,40,50,};//값이 있어야만 방이 증가한다.
//		int[] score2 = {10,20,30,40,50,};
//		for(int i=0; i<score2.length; i++){
//			System.out.println(score2[i]);
//		}
//		
//		int[] ss;
//		ss = new int[2];
//		
//		int[] ss2;
//		ss2= new int[]{10,20,30};
//		
////		이렇게는 불가능하다
////		int[] ss3;
////		ss2={10,20,30};
//		//3.변수 names에 같은 팀원의 이름들을 저장하세요
//		String[] names=new String[]{"박상빈","길민선","성원제","박세웅"};
//		for(int i=0; i<names.length; i++){
//			System.out.println(names[i]);
//		}
//		//이
//		//영
//		//훈
//		//유
//		//은
//		//서
//		//0:2:1:System.out.println(name[?];
//		//0:3:1:System.out.println(name[?][?];
//		String[] name = new String[]{"박상빈","길민선"};
//		for(int i=0; i<name.length; i++){
//			for(int j=0; j<name[i].length(); j++){
//			System.out.println(name[i].charAt(j));
//			}
//			System.out.println("------");
//		}
		
		
		
		
		
		
		
	}
}

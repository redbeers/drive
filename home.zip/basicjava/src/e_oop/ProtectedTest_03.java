package e_oop;

public class ProtectedTest_03 {
	public static  void Add(){
		
	}
	protected int b;
	int c;
	private int d;
}


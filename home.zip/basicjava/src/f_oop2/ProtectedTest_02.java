package f_oop2;

public class ProtectedTest_02 {
	
	public int a;
	protected int b;
	int c;
	private int d;
	
	public ProtectedTest_02() {
		// TODO Auto-generated constructor stub
	}
	
}

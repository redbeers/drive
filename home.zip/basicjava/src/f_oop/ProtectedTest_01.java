package f_oop;

import e_oop.ProtectedTest_03;

public class ProtectedTest_01 extends ProtectedTest_03{

	public static void main(String[] args) {
		ProtectedTest_02 p2 = new ProtectedTest_02();
		
		ProtectedTest_03 p3 = new ProtectedTest_03();
		p3.Add();
		ProtectedTest_01 p1 = new ProtectedTest_01();
		
	}

}

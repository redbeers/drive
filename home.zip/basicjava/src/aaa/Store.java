package aaa;

public class Store {

	public static void main(String[] args) {
		

	}

}

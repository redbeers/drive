package kr.or.profit.service;

import java.util.List;
import java.util.Map;

import kr.or.profit.vo.QnaVO;

public interface QnaService {

	List<?> qnaList() throws Exception;

	Map<String, Object> qnaDetail(Map<String, Object> map) throws Exception;

	int qnaUpdate(Map<String, Object> map) throws Exception;

	int qnaDelete(Map<String, Object> map) throws Exception;

	int qnaInsert(Map<String, Object> map) throws Exception;

}

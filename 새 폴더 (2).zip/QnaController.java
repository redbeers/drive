package kr.or.profit.web;

import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.servlet.ServletException;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletResponse;

import org.apache.catalina.servlet4preview.http.HttpServletRequestWrapper;
import org.apache.commons.io.FileUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.google.gson.JsonObject;
import com.ibatis.sqlmap.engine.scope.SessionScope;

import kr.or.profit.service.QnaService;
import kr.or.profit.vo.CommunityVO;
import kr.or.profit.vo.QnaVO;

@Controller
public class QnaController {

	@Resource(name = "qnaService")
	private QnaService qnaService;

	/**
	 * 문의하기 목록(qnaList)
	 *
	 * @author 박상빈
	 * @param List data에 넣어서 qna/qnaList로 간다
	 * @return "qna/qnaList"
	 * @exception Exception
	 */
	@RequestMapping(value = "qnaList.do", method = RequestMethod.GET)
	public String qnaList(@RequestParam Map<String, Object> map, ModelMap model) throws Exception {
		List<?> qnaList = qnaService.qnaList();
		model.addAttribute("data", qnaList);
		return "qna/qnaList";
	}

	/**
	 * 문의하기 add화면(qnaAdd)
	 *
	 * @author 박상빈
	 * @param
	 * @return "qna/qnaAdd"
	 * @exception Exception
	 */
	@RequestMapping(value = "qnaAdd.do", method = RequestMethod.GET)
	public String qnaAdd() throws Exception {
		return "qna/qnaAdd";
	}

	/**
	 * 문의하기 등록(qnaInsert)
	 *
	 * @author 박상빈
	 * @param       if 파일이 비어있으면 null을 넣어준다
	 * @param model list로 data로 보내준다
	 * @param data  정상추가시 1반환
	 * @return "qna/qnaList"
	 * @exception Exception
	 */
	//	@RequestMapping(value = "qnaAdd.do", method = RequestMethod.POST)
	//	public String qnaInsert(@RequestParam Map<String, Object> map, ModelMap model, HttpSession ssion) throws Exception {
	//
	//		if(map.get("files").equals("")) {
	//			map.put("files","파일없음");
	//		}
	//		map.put("memberId", ssion.getAttribute("memberId"));
	//		int qnaInsert = qnaService.qnaInsert(map);
	//
	//		List<?> qnaList = qnaService.qnaList();
	//		model.addAttribute("data", qnaList);
	//		return "qna/qnaList";
	//	}

	/**
	 * 문의하기 상세보기(qnaDetail)
	 *
	 * @author 박상빈
	 * @param map   qnaList에서 communitySeq 값을 가져온다
	 * @param model communitySeq해당하는 내용을 보내준다
	 * @return "qna/qnaDetail"
	 * @exception Exception
	 */
	@RequestMapping(value = "qnaDetail.do", method = RequestMethod.GET)
	public String qnaDetail(@RequestParam Map<String, Object> map, ModelMap model) throws Exception {
		System.out.println("map : " + map);
		Map<String, Object> qnaDetail = qnaService.qnaDetail(map);
		model.addAttribute("data", qnaDetail);
		return "qna/qnaDetail";
	}

	/**
	 * 문의하기 수정 화면(qnaMod)
	 *
	 * @author 박상빈
	 * @param map       qnaDetail에서 communitySeq 값을 가져온다
	 * @param qnaDetail data에 담아 넘겨준다
	 * @return "qna/qnaMod"
	 * @exception Exception
	 */
	@RequestMapping(value = "qnaMod.do", method = RequestMethod.GET)
	public String qnaMod(@RequestParam Map<String, Object> map, ModelMap model) throws Exception {
		Map<String, Object> qnaDetail = qnaService.qnaDetail(map);
		model.addAttribute("data", qnaDetail);
		return "qna/qnaMod";
	}

	/**
	 * 문의하기 수정(qnaMod)
	 *
	 * @author 박상빈
	 * @param           if 파일이 없는 경우 파일없음 저장
	 * @param qnaDetail 화면 새로고침을 위해 파라미터로 communitySeq가지고 qnaDetail.do로 간다 redirect:"(새로고칠 화면.jsp) 화면이름 이름"
	 * @return "redirect:qnaDetail.do?communitySeq="+map.get("communitySeq");
	 * @exception Exception
	 */
	@RequestMapping(value = "qnaMod.do", method = RequestMethod.POST)
	public String qnaUpdate(@RequestParam Map<String, Object> map, ModelMap model) throws Exception {
		if (map.get("files").equals("")) {
			map.put("files", "파일없음");
		}
		int qnaUpdate = qnaService.qnaUpdate(map);
		Map<String, Object> qnaDetail = qnaService.qnaDetail(map);
		model.addAttribute("data", qnaDetail);
		return "redirect:qnaDetail.do?communitySeq=" + map.get("communitySeq");
	}

	/**
	 * 문의하기 글 삭제(qnaAdd)
	 *
	 * @author 박상빈
	 * @param map     qnaDetail에서 해당 communitySeq 가지고옴
	 * @param qnaList qnaList갈때 리스트 뿌릴거(여기서 않가지고가면 않나옴)
	 * @return "qna/qnaList"
	 * @exception Exception
	 */
	@RequestMapping(value = "qnaDelete.do", method = RequestMethod.GET)
	public String qnaDelete(@RequestParam Map<String, Object> map, ModelMap model) throws Exception {
		System.out.println("옴 = " + map);
		int qnaDelete = qnaService.qnaDelete(map);
		System.out.println("돌아옴 = " + qnaDelete);

		List<?> qnaList = qnaService.qnaList();
		model.addAttribute("data", qnaList);
		System.out.println("가지고갈거 = " + qnaList);
		return "redirect:qnaList.do";
	}

//	/**
//	 * 게시판 이미지 업로드
//	 *
//	 * @author 박상빈
//	 * @param MultipartFile,HttpServletRequest,HttpServletResponse
//	 * @return 이미지
//	 * @throws Exception
//	 */
//
//	@RequestMapping(value = "qnaProfileImage.do", method = RequestMethod.POST)
//	@ResponseBody
//	public void qnaProfileImage(MultipartFile file, HttpServletRequest request, HttpServletResponse response) throws Exception {
//		response.setContentType("text/html;charset=utf-8");
//		PrintWriter out = response.getWriter();
//		// 업로드할 폴더 경로
//		String realFolder = request.getSession().getServletContext().getRealPath("profileUpload");
//
//		UUID uuid = UUID.randomUUID();
//		System.out.println("uuid = " + uuid);
//		// 업로드할 파일 이름
//		String org_filename = file.getOriginalFilename();
//		String str_filename = uuid.toString() + "_psb_" + org_filename;
//
//		System.out.println("원본 파일명 : " + org_filename);
//		System.out.println("저장할 파일명 : " + str_filename);
//
//		String filepath = "\\\\192.168.41.6\\upload\\profit" + "\\" + str_filename;
//		System.out.println("파일경로 : " + filepath);
//		//		String finalpath = "http://192.168.41.6:9999/upload/profit/" + str_filename;
//		String finalpath = "http://192.168.41.6:9999/upload/profit/" + str_filename;
//		System.out.println("최종경로 : " + finalpath);
//
//		File f = new File(filepath);
//		if (!f.exists()) {
//			f.mkdirs();
//		}
//		file.transferTo(f);
//		out.println(finalpath);
//		out.close();
//	}

	/**
	 * 문의하기 등록(qnaInsert)
	 *
	 * @author 박상빈
	 * @param       if 파일이 비어있으면 null을 넣어준다
	 * @param model list로 data로 보내준다
	 * @param data  정상추가시 1반환
	 * @return "qna/qnaList"
	 * @exception Exception
	 */
	@RequestMapping(value = "qnaAdd.do", method = RequestMethod.POST)
	public String qnaInsert(@RequestParam Map<String, Object> map, HttpSession ssion, HttpServletRequest request, Model model) throws Exception {
		System.out.println("qnaAdd옴");
		System.out.println("ssion옴" + ssion.getAttribute("memberId"));

		map.put("memberId", ssion.getAttribute("memberId"));

		System.out.println("map = " + map);
		int qnaInsert = qnaService.qnaInsert(map);

		System.out.println("돌아옴 = " + qnaInsert);
		List<?> qnaList = qnaService.qnaList();
		model.addAttribute("data", qnaList);

//		request.setCharacterEncoding("utf-8");
//		PrintWriter out = response.getWriter();
//		out.println("<script>alert('회원가입이 완료되었습니다.'); location.href='home.do';</script>");

		return "<script>alert('회원가입이 완료되었습니다.'); location.href='qnaList.do';</script>" ;
	}

	@RequestMapping(value = "uploadSummernoteImageFile.do", produces = "application/json; charset=utf8")
	@ResponseBody
	public String uploadSummernoteImageFile(@RequestParam("file") MultipartFile multipartFile, HttpServletRequest request) {
		System.out.println("컨트롤러");
		JsonObject jsonObject = new JsonObject();

//		String fileRoot = "C:\\summernote_image\\"; // 외부경로로 저장을 희망할때.

		// 내부경로로 저장
		String contextRoot = new HttpServletRequestWrapper(request).getRealPath("/");
		System.out.println("contextRoot : " + contextRoot);

		String fileRoot = contextRoot+"resources/fileupload/";
		System.out.println("fileRoot : " + fileRoot);

		String originalFileName = multipartFile.getOriginalFilename(); //오리지날 파일명
		System.out.println("originalFileName : " + originalFileName);

		String extension = originalFileName.substring(originalFileName.lastIndexOf(".")); //파일 확장자
		System.out.println("extension : " + extension);

		String savedFileName = UUID.randomUUID() + extension; //저장될 파일 명
		System.out.println("savedFileName : " + savedFileName);

		File targetFile = new File(fileRoot + savedFileName);
		try {
			InputStream fileStream = multipartFile.getInputStream();
			FileUtils.copyInputStreamToFile(fileStream, targetFile); //파일 저장
			jsonObject.addProperty("url", "/resources/fileupload/" + savedFileName); // contextroot + resources + 저장할 내부 폴더명
			System.out.println("여기1" + jsonObject.get("url"));
			jsonObject.addProperty("responseCode", "success");
			System.out.println("여기2" + jsonObject.get("responseCode"));

		} catch (IOException e) {
			FileUtils.deleteQuietly(targetFile); //저장된 파일 삭제
			jsonObject.addProperty("responseCode", "error");
			e.printStackTrace();
		}
		String a = jsonObject.toString();
		return a;
	}

}
package package_Database;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import package_VO.AdminVO;
import package_VO.CategoryVO;
import package_VO.CustomerVO;
import package_VO.OrderDetailsVO;
import package_VO.OrderInformationVO;
import package_VO.ProductVO;
import package_VO.QuestionVO;

public class Database {

	public static int snack_seq = 2;
	public static int list_seq = 0;

	private final AdminVO admin = new AdminVO();
	// admin 계정

	private final List<CustomerVO> customerList = new ArrayList<>();
	// 손님 목록

	private final List<ProductVO> proList = new ArrayList<>();
	// 상품리스트

	private final List<QuestionVO> questionList = new ArrayList<>();

	// 손님 목록/겸 회원리스트

	private final List<OrderInformationVO> orderinfo = new ArrayList<>();

	// 고객 주문내역 리스트!!!

	private final List<OrderDetailsVO> orderdetails = new ArrayList<>();
	
	private final List<CategoryVO> catelist = new ArrayList<>();

	/**
	 * <code>insertUser</code> 메서드는 새로운 사용자를 추가하기 위한 메서드입니다.
	 * 
	 * @param user
	 *            : 추가할 UserVO 객체
	 * @return 추가에 성공한다면 true, 실패한다면 false 반환
	 * @author
	 */

	public boolean insertUser(CustomerVO user) {
		return customerList.add(user);
	}

	/**
	 * <code>userIdUniqueCheck</code> 메서드는 입력한 id가 유일한 값이 맞는지 판별하는 메서드입니다.
	 * 
	 * @param userId
	 *            : 유효성을 확인하기 위한 String 객체
	 * @return 유일한 값이라면 true, 그렇지 않은 경우라면 false 반환
	 */
	public boolean userIdUniqueCheck(String userId) {
		if (admin.getId().equals(userId)) {
			return false;
		}
		return selectCustomer(userId) == null;
	}

	/**
	 * <code>adminLogin</code> 메서드는 해당 로그인 요청이 관리자 계정과 일치하는지 판별하는 메서드입니다.
	 * 
	 * @param loginInfo
	 *            : user_id, user_pw를 담은 Map
	 * @return 로그인에 성공한다면 true, 그렇지 않다면 false.
	 * @author
	 */
	public boolean adminLogin(Map<String, String> loginInfo) {
		return admin.getId().equals(loginInfo.get("user_id"))
				&& admin.getPw().equals(loginInfo.get("user_pw"));
	}

	/**
	 * <code>selectAllUser</code> 메서드는 모든 유저의 정보를 불러오기 위한 메서드입니다.
	 * 
	 * @return 모든 유저의 정보를 포함한 List
	 * @author
	 */
	public List<CustomerVO> selectAllUser() {
		List<CustomerVO> userList = new ArrayList<>();
		for (CustomerVO user : this.customerList) {
			userList.add(user);

		}
		return userList;
	}

	/**
	 * <code>selectUser</code> 메서드는 선택한 유저의 정보를 불러오기 위한 메서드입니다.
	 * 
	 * @param id
	 *            : 사용자의 고유 id
	 * @return 사용자의 정보를 담고 있는 UserVO 객체
	 * @author
	 */
	public CustomerVO selectCustomer(String id) {
		for (CustomerVO user : customerList) {
			if (user.getCustomerID().equals(id)) {
				return user;
			}
		}
		return null;
	}

	/**
	 * <code>userLogin</code> 메서드는 해당 로그인 요청이 사용자 계정과 일치하는지 판별하는 메서드입니다.
	 * 
	 * @param loginInfo
	 *            : user_id, user_pw를 담은 Map
	 * @return 로그인에 성공한다면 true, 그렇지 않다면 false.
	 * @author
	 */
	public boolean userLogin(Map<String, String> loginInfo) {
		if (selectCustomer(loginInfo.get("user_id")) == null) {
			return false;
		}
		return selectCustomer(loginInfo.get("user_id")).getPassword().equals(
				loginInfo.get("user_pw"));
		// && selectUser(loginInfo.get("user_id")).isActivate();
	}

	// ////////////////////////////////////

	// CRUD 중 R!!!
	public List<ProductVO> selectAllProduct() {

		List<ProductVO> productList = new ArrayList<>();
		for (ProductVO productList1 : this.proList) {
			if (productList1.isActivate()) {
				productList.add(productList1);
			}
		}
		return productList;
		// return proList;
	}

	/**
	 * selectProduct 메서드는 상품을 선택하는 메서드입니다.
	 * 
	 * @param user
	 * @author 성원제3
	 * @return
	 */
	public ProductVO selectProduct(int pro_seq) {
		for (ProductVO select : proList) {
			if (select.getSeq() == pro_seq) {
				return select;
			}
		}
		return null;
	}

	/**
	 * insertProduct 메서드는 새로운 상품을 추가하기 위한 메서드입니다.
	 * 
	 * @param product
	 *            : 추가할 ProductVO 객체
	 * @return 추가에 성공하면 true, 실패하면 false 반환
	 * @author 성원제1
	 */
	public boolean insertProduct(ProductVO productVO) {
		return proList.add(productVO);
	}

	/**
	 * <code>removeProduct</code> 메서드는 상품을 삭제하가 위한 메서드입니다.
	 * 
	 * @param seq
	 *            :
	 * @return 추가에 성공한다면 true, 실패한다면 false 반환
	 * @author 성원제2
	 */
	public int removeProduct(int seq) {
		// 타입을 맞춰서 변수에 시퀀스를 넣어
		// 그 시퀀스를 엑티베이트에서 트루풜스로 바꿔 트루면 삭제, 폴스면 아니고
		ProductVO product = selectProduct(seq);
		if (product == null) {
			product.setActivate(true);
			return 0;
		}

		product.setActivate(false);
		return 1;
	}

	/**
	 * <code>selectAllQuestion</code> 메서드는 고객의 리스트 전부를 읽기 위한 메서드입니다.
	 * 
	 * 
	 * 
	 * @return questionList
	 * @author 성원제4
	 */
	public List<QuestionVO> selectAllQuestion() {
		List<QuestionVO> question = new ArrayList<>();
		for (QuestionVO qusestion1 : this.questionList) {
			if (qusestion1.isActivate()) {
				question.add(qusestion1);
			}
		}
		return question;
	}

	/**
	 * @insertQuestion - 관리자 메서드 : 답글을 입력하는 메서드입니다.
	 * 
	 * @date 2021. 1. 29.
	 * @author 성원제
	 */
	public boolean insertQuestion(QuestionVO qusetionVO) {
		List<QuestionVO> question = new ArrayList<>();
		questionList.add(qusetionVO);

		return questionList.add(qusetionVO);

	}

	/**
	 * <code>insertOrderInformation</code> 메서드는 새로운 주문을 추가하기 위한 메서드입니다.
	 * 
	 * @param orderInformation
	 *            : 추가할 OrderInformationVO 객체
	 * @return 추가에 성공하면 true, 실패하면 false 반환
	 * @author 길민선
	 */
	public boolean insertOrderInformation(OrderInformationVO orderInformation) {
		return orderinfo.add(orderInformation);
	}

	/**
	 * <code>insertOrderInformation</code> 메서드는 새로운 주문을 추가하기 위한 메서드입니다.
	 * 
	 * @param orderInformation
	 *            : 추가할 OrderInformationVO 객체
	 * @return 추가에 성공하면 true, 실패하면 false 반환
	 * @author 길민선
	 */
	public boolean insertOrderDetails(OrderDetailsVO orderdetail) {
		return orderdetails.add(orderdetail);
	}

	/**
	 * <code>selectAllOrderInformation</code> 메서드는 모든 주문내역의 정보를 불러오기 위한 메서드입니다.
	 * <code>selectOrderInformation</code> 메서드는 특정 유저에 대한 주문내역의 정보를 불러오기 위한
	 * 메서드입니다.--선발대
	 * !!!!!shoplist 장바구니!!!!!
	 * @return 모든 주문 정보를 담고 있는 List
	 * @author 길민선
	 */
	public List<OrderInformationVO> selectAllOrderInformationTrue(String user_id) {

		List<OrderInformationVO> orderInformationList = new ArrayList<>();

		for (int i = 0; i < orderinfo.size(); i++) {
			if (user_id.equals(orderinfo.get(i).getCustomer_id())) {
				if(orderinfo.get(i).isActivate() == true){
					orderInformationList.add(orderinfo.get(i));
				}
			}
		}
		return orderInformationList;
	}
	/**
	 * <code>selectAllOrderInformation</code> 메서드는 모든 주문내역의 정보를 불러오기 위한 메서드입니다.
	 * <code>selectOrderInformation</code> 메서드는 특정 유저에 대한 주문내역의 정보를 불러오기 위한
	 * 메서드입니다.--선발대
	 * !!!!!shoplist 장바구니!!!!!
	 * @return 모든 주문 정보를 담고 있는 List
	 * @author 길민선
	 */
	public List<OrderInformationVO> selectAllOrderInformationFalse(String user_id) {

		List<OrderInformationVO> orderInformationList = new ArrayList<>();

		for (int i = 0; i < orderinfo.size(); i++) {
			if (user_id.equals(orderinfo.get(i).getCustomer_id())) {
				if(orderinfo.get(i).isActivate() == false){
					orderInformationList.add(orderinfo.get(i));
				}
			}
		}
		return orderInformationList;
	}
	
	
	/**
	 * 카테고리VO의 모든 정보를 반환할 리스트-고객 매서드
	 * @param 
	 * @return catelist
	 * @author 길민선
	 */
	public List<CategoryVO> selectAllCategory(){
		return catelist;
	}
	
	/**
	 * 카테고리 시퀀스를 매개 변수로 받아서 시퀀스에 맞는 상품들만 리스트에 담아서 반환하는 메서드-고객 매서드
	 * 리스트는 ProductVO 임
	 * @param 
	 * @return categorylist
	 * @author 길민선
	 */
	public List<ProductVO> selectCategory(int cate_seq){
		List<ProductVO> categorylist = new ArrayList<>();
		for(int i = 0; i<proList.size();i++){
			if(cate_seq == (proList.get(i).getCategory_seq())){
				categorylist.add(proList.get(i));
			}
		}
		return categorylist;
	}
	
	public OrderInformationVO selectOrderInfoSeq(int orderinfo_seq) {
		for (OrderInformationVO select : orderinfo) {
			if (select.getSeq() == orderinfo_seq) {
				return select;
			}
		}
		return null;
	}
	
	public OrderDetailsVO selectSeq(int order_seq) {
		for (OrderDetailsVO select : orderdetails) {
			if (select.getSeq() == order_seq) {
				return select;
			}
		}
		return null;
	}
	
	
	
	public List<OrderDetailsVO> selectAllOrderdetailsSeq(List<OrderInformationVO> orderList) {
		List<OrderDetailsVO> orderseq = new ArrayList<>();
		
		for(int i = 0; i<orderdetails.size(); i++){
			if(orderList.get(i).getSeq() == orderdetails.get(i).getOrder_seq()){
				orderseq.add(orderdetails.get(i));
			}
		}
		return orderseq;
	}
	
	
	

	
	
	
		
	{
		CategoryVO cate1 = new CategoryVO();
		cate1.setKind("스낵리스트");
		cate1.setSeq(1);
		catelist.add(cate1);
		
		CategoryVO cate2 = new CategoryVO();
		cate2.setKind("젤리리스트");
		cate2.setSeq(2);
		catelist.add(cate2);
		
		CategoryVO cate3 = new CategoryVO();
		cate3.setKind("초콜릿리스트");
		cate3.setSeq(3);
		catelist.add(cate3);
		
	}

	{
		ProductVO prod1 = new ProductVO();
		prod1.setSeq(1);
		prod1.setName("새우깡");
		prod1.setPrice(1000);
		prod1.setStock(100);
		prod1.setCategory_seq(1);
		proList.add(prod1);

		ProductVO prod2 = new ProductVO();
		prod2.setSeq(2);
		prod2.setName("포카칩");
		prod2.setPrice(1000);
		prod2.setStock(500);
		prod2.setCategory_seq(1);
		proList.add(prod2);
		
		ProductVO prod3 = new ProductVO();
		prod3.setSeq(3);
		prod3.setName("하리보");
		prod3.setPrice(1000);
		prod3.setStock(100);
		prod3.setCategory_seq(2);
		proList.add(prod3);
		
		ProductVO prod4 = new ProductVO();
		prod4.setSeq(4);
		prod4.setName("마이구미");
		prod4.setPrice(1000);
		prod4.setStock(500);
		prod4.setCategory_seq(2);
		proList.add(prod4);
		
		ProductVO prod5 = new ProductVO();
		prod5.setSeq(5);
		prod5.setName("허쉬");
		prod5.setPrice(1000);
		prod5.setStock(100);
		prod5.setCategory_seq(3);
		proList.add(prod5);
		
		ProductVO prod6 = new ProductVO();
		prod6.setSeq(6);
		prod6.setName("페레로로쉐");
		prod6.setPrice(1000);
		prod6.setStock(500);
		prod6.setCategory_seq(3);
		proList.add(prod6);
	}

	{
		CustomerVO user1 = new CustomerVO();
		user1.setCustomerID("1");
		user1.setPassword("1");
		user1.setName("길민선");
		user1.setPoint(10000);
		customerList.add(user1);

	}
	{
		CustomerVO user2 = new CustomerVO();
		user2.setCustomerID("2");
		user2.setPassword("2");
		user2.setName("박상빈");
		user2.setPoint(10000);
		customerList.add(user2);

	}
	{
		QuestionVO question1 = new QuestionVO();
		question1.setSeq_num(1);
		question1.setTitle("저기요...이건 아니잖아요");
		question1
				.setContent("아니..제품이 왜케 없어요 두개라뇨..매장은 20평인데 말이 되나요??\r 두개 사러 여기까지 오게했다고?");
		question1.getCustomer_id();
		questionList.add(question1);
	}
}

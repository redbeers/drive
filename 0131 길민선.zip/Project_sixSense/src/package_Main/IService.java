package package_Main;

import java.util.List;
import java.util.Map;

import package_VO.CategoryVO;
import package_VO.CustomerVO;
import package_VO.OrderDetailsVO;
import package_VO.OrderInformationVO;
import package_VO.ProductVO;
import package_VO.QuestionVO;

public interface IService {

	/**
	 * <상품 리스트 보기>
	 * 
	 * @return 
	 * @param 리스트 다 불러오는 거니까 파라미터 없음
	 * @author 
	 * 
	 */
	List<ProductVO> selectAllProduct();
	
	/**
	 * <상품 추가> 관리자 메서드
	 * 
	 * @since 21.01.28
	 * @author 성원제1
	 */
	boolean insertProduct(ProductVO productVO);
	
	/**
	 * <상품 삭제> 관리자 메서드
	 * 
	 * 
	 * @since 21.01.28
	 * @author 성원제2
	 */
	int removeProduct(int pro_seq);
	
	/**
	 * <고객의 소리 리스트 보기> 관리자 메서드
	 * 
	 * @since 21.01.29
	 * @author 성원제3
	 */
	List<QuestionVO> selectAllQuestion();
	
	/**
	 * 회원가입 - 회원 정보 DB에 입력
	 * @insertQuestion
	 * @param String question
	 * 
	 * @date 2021. 1. 29.
	 * @author 성원제
	 */
	boolean insertQuestion(QuestionVO qusetion);
	
	/**
	 * 회원가입 - 유저 정보 DB에 입력
	 * 
	 * @param userVO
	 * @return 성공 시 true, 실패 시 false 반환
	 * @author
	 */
	boolean insertUser(CustomerVO user);

	/**
	 * id 중복 여부와 조건을 충분히 만족하는지 확인
	 * 
	 * @param id
	 * @return 만족하면 true, 불만족하면 false 반환
	 */
	boolean checkId(String id);

	/**
	 * 관리자 계정 로그인
	 * 
	 * @param loginInfo
	 * @return 로그인 성공 시 true, 실패 시 false 반환
	 */
	boolean adminLogin(Map<String, String> loginInfo);

	/**
	 * 회원 계정 로그인
	 * 
	 * @param loginInfo
	 *            <"user_id", user_id>, <"user_pw", user_pw> 키/값을 전송하여 로그인 성공여부
	 *            반환받음
	 * @return 로그인 성공 시 true, 실패 시 false 반환
	 * @author
	 */
	boolean userLogin(Map<String, String> loginInfo);

	/**
	 * 선택한 회원 정보 가져오기 - 관리자 메서드
	 * 
	 * @param user_id
	 * @return UserVO
	 * @author 길민선
	 */
	CustomerVO selectCustomer(String user_id);
	
	
	
	/**
	 * 주문 정보 추가 - 고객 메서드
	 * 
	 * @param orderInformation
	 * @return 성공 시 true, 실패 시 false 반환
	 * @author 길민선
	 */
	boolean insertOrderInformation(OrderInformationVO orderInformation);
	
	/**
	 * 주문 상세 정보 추가 - 고객 메서드
	 * 
	 * @param orderdetail
	 * @return 성공 시 true, 실패 시 false 반환
	 * @author 길민선
	 */
	boolean insertOrderDetails(OrderDetailsVO orderdetail);
	
	/**
	 * 고객 주문 내역 보기 - 고객 메서드
	 * 
	 * @param user_id
	 * @return List<OrderInformationVO>
	 * @author 길민선
	 */
	List<OrderInformationVO> selectAllOrderInformation(String user_id);
	
	/**
	 * 고객 상세 주문 내역 보기 - 고객 메서드
	 * 
	 * @param selectNum
	 * @return List<OrderInformationVO>
	 * @author 길민선
	 */
	List<OrderInformationVO> selectOrderDetails();

	
	public ProductVO selectProductInfo(int pro_seq);
	
	public List<CategoryVO> selectAllCategory();
	
	public List<ProductVO> selectCategory(int cate_seq);
	
	List<OrderInformationVO> selectAllOrderInformationTrue(String user_id);
	
	List<OrderInformationVO> selectAllOrderInformationFalse(String user_id);
	
	OrderDetailsVO selectSeq(int order_seq);
	
	List<OrderDetailsVO> selectAllOrderdetailsSeq(List<OrderInformationVO> orderList);
	
	OrderInformationVO selectOrderInfoSeq(int orderinfo_seq);
}

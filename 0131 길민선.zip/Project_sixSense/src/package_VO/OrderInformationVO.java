package package_VO;

public class OrderInformationVO {
	private int seq;//pk
	private String customer_id;//fk
	private int total_price;
	private int category_seq;;
	private boolean isActivate = true;
	
	public int getSeq() {
		return seq;
	}

	public void setSeq(int seq) {
		this.seq = seq;
	}

	public String getCustomer_id() {
		return customer_id;
	}

	public void setCustomer_id(String customer_id) {
		this.customer_id = customer_id;
	}

	public int getTotal_price() {
		return total_price;
	}

	public void setTotal_price(int total_price) {
		this.total_price = total_price;
	}

	public int getCategory_seq() {
		return category_seq;
	}

	public void setCategory_seq(int category_seq) {
		this.category_seq = category_seq;
	}

	public boolean isActivate() {
		return isActivate;
	}

	public void setActivate(boolean isActivate) {
		this.isActivate = isActivate;
	}

	@Override
	public String toString() {
		return "\r" + "[" + seq + "]" + " 총 주문금액 : " + total_price
				+ "\r";
	}
	
	
	
	

	

}
